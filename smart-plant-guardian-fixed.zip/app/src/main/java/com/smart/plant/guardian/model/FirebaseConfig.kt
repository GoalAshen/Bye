package com.smart.plant.guardian.model

data class FirebaseConfig(
    val databaseUrl: String = "",
    val apiKey: String = "",
    val projectId: String = "",
    val appId: String = "",
    val email: String = "",
    val password: String = "",
    val idToken: String = "",
    val refreshToken: String = "",
    val localId: String = "",
    val tokenExpiresEpochMs: Long = 0L
) {
    val isConfigured: Boolean
        get() = databaseUrl.trim().isNotBlank() &&
                apiKey.trim().isNotBlank() &&
                appId.trim().isNotBlank()

    val isAuthenticated: Boolean
        get() = isConfigured && idToken.isNotBlank() && localId.isNotBlank()

    val cleanDatabaseUrl: String
        get() {
            var url = databaseUrl.trim()
            if (url.endsWith("/")) {
                url = url.substring(0, url.length - 1)
            }
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://$url"
            }
            return url
        }
}
