package com.smart.plant.guardian.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun SoilGaugesRow(
    zone1: Int?,
    zone2: Int?,
    zone3: Int?,
    dryThreshold: Int,
    targetThreshold: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("soil_gauges_card"),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Soil Moisture Zones",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Target: $targetThreshold%",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                SoilGauge(
                    zoneName = "Zone 1",
                    percent = zone1,
                    dryThreshold = dryThreshold,
                    targetThreshold = targetThreshold
                )
                SoilGauge(
                    zoneName = "Zone 2",
                    percent = zone2,
                    dryThreshold = dryThreshold,
                    targetThreshold = targetThreshold
                )
                SoilGauge(
                    zoneName = "Zone 3",
                    percent = zone3,
                    dryThreshold = dryThreshold,
                    targetThreshold = targetThreshold
                )
            }
        }
    }
}

@Composable
fun SoilGauge(
    zoneName: String,
    percent: Int?,
    dryThreshold: Int,
    targetThreshold: Int,
    modifier: Modifier = Modifier,
    size: Dp = 90.dp
) {
    val trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
    val errorColor = MaterialTheme.colorScheme.error // Red = Dry
    val primaryColor = MaterialTheme.colorScheme.primary // Green = Good
    val secondaryColor = MaterialTheme.colorScheme.secondary // Blue/Aqua = Wet

    // Determine gauge status color from M3 roles
    val (statusColor, statusLabel) = when {
        percent == null -> Pair(trackColor, "--")
        percent < dryThreshold -> Pair(errorColor, "Dry")
        percent < targetThreshold + 15 -> Pair(primaryColor, "Good")
        else -> Pair(secondaryColor, "Wet")
    }

    val animatedSweep by animateFloatAsState(
        targetValue = if (percent != null) (percent.coerceIn(0, 100) / 100f) * 240f else 0f,
        animationSpec = tween(durationMillis = 600),
        label = "sweepAnim"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(size),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(size)) {
                val strokeWidth = 8.dp.toPx()
                val diameter = this.size.minDimension - strokeWidth
                val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)
                val arcSize = Size(diameter, diameter)

                // Background track arc (240 degrees from 150 to 390)
                drawArc(
                    color = trackColor,
                    startAngle = 150f,
                    sweepAngle = 240f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )

                // Active value arc
                if (percent != null && animatedSweep > 0f) {
                    drawArc(
                        color = statusColor,
                        startAngle = 150f,
                        sweepAngle = animatedSweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (percent != null) "$percent%" else "--",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (percent != null) statusColor else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = zoneName,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
    }
}
