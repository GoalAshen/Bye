package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.smart.plant.guardian.model.HistoryPoint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ChartTimeRange(val label: String, val durationMs: Long) {
    ONE_HOUR("1h", 60 * 60 * 1000L),
    TWENTY_FOUR_HOURS("24h", 24 * 60 * 60 * 1000L),
    SEVEN_DAYS("7d", 7 * 24 * 60 * 60 * 1000L)
}

enum class ChartMetric(val label: String, val unit: String) {
    SOIL("Soil Avg", "%"),
    TEMP("Temp", "°C"),
    HUMIDITY("Humidity", "%"),
    LIGHT("Light", "%"),
    BATTERY("Battery", "%")
}

@Composable
fun HistoryChartCard(
    history: List<HistoryPoint>,
    nowServerMs: Long,
    modifier: Modifier = Modifier
) {
    var selectedRange by remember { mutableStateOf(ChartTimeRange.TWENTY_FOUR_HOURS) }
    var selectedMetric by remember { mutableStateOf(ChartMetric.SOIL) }

    // Filter points by range
    val cutoff = nowServerMs - selectedRange.durationMs
    val filteredPoints = remember(history, cutoff) {
        history.filter { it.timestampMs >= cutoff }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("history_chart_card"),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Telemetry History",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Range Selector (1h, 24h, 7d)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ChartTimeRange.entries.forEach { range ->
                        FilterChip(
                            selected = selectedRange == range,
                            onClick = { selectedRange = range },
                            label = { Text(range.label, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.height(32.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Metric Selector Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ChartMetric.entries.forEach { metric ->
                    FilterChip(
                        selected = selectedMetric == metric,
                        onClick = { selectedMetric = metric },
                        label = { Text(metric.label, style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer
                        ),
                        modifier = Modifier.height(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Chart Canvas or Empty State
            if (filteredPoints.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Waiting for device data…\nNo history recorded in past ${selectedRange.label}.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                HistoryLineChart(
                    points = filteredPoints,
                    metric = selectedMetric,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                )
            }
        }
    }
}

@Composable
fun HistoryLineChart(
    points: List<HistoryPoint>,
    metric: ChartMetric,
    modifier: Modifier = Modifier
) {
    val lineColor = MaterialTheme.colorScheme.primary
    val gradientColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
    val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant

    // Extract numerical values
    val values: List<Float> = points.mapNotNull { p ->
        when (metric) {
            ChartMetric.SOIL -> p.soilAvg ?: p.zone1?.toFloat()
            ChartMetric.TEMP -> p.tempC
            ChartMetric.HUMIDITY -> p.humidity
            ChartMetric.LIGHT -> p.lightPercent?.toFloat()
            ChartMetric.BATTERY -> p.batteryPercent?.toFloat()
        }
    }

    if (values.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text(
                text = "Waiting for device data…",
                style = MaterialTheme.typography.bodyMedium,
                color = labelColor
            )
        }
        return
    }

    val minVal = (values.minOrNull() ?: 0f).coerceAtLeast(0f)
    val maxVal = ((values.maxOrNull() ?: 100f) + 5f).coerceAtLeast(minVal + 10f)

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Max: ${String.format("%.1f", maxVal)}${metric.unit}",
                style = MaterialTheme.typography.labelSmall,
                color = labelColor
            )
            val latest = values.lastOrNull()
            Text(
                text = if (latest != null) "Current: ${String.format("%.1f", latest)}${metric.unit}" else "--",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = lineColor
            )
            Text(
                text = "Min: ${String.format("%.1f", minVal)}${metric.unit}",
                style = MaterialTheme.typography.labelSmall,
                color = labelColor
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            val width = size.width
            val height = size.height
            val paddingBottom = 16f

            // Draw 3 horizontal grid lines
            for (i in 0..2) {
                val y = height * (i / 2f)
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f
                )
            }

            if (values.size == 1) {
                // Single point
                val cx = width / 2f
                val norm = (values[0] - minVal) / (maxVal - minVal)
                val cy = height - (norm * (height - paddingBottom))
                drawCircle(color = lineColor, radius = 6.dp.toPx(), center = Offset(cx, cy))
                return@Canvas
            }

            val dx = width / (values.size - 1)
            val path = Path()
            val fillPath = Path()

            values.forEachIndexed { i, v ->
                val x = i * dx
                val norm = ((v - minVal) / (maxVal - minVal)).coerceIn(0f, 1f)
                val y = height - (norm * (height - paddingBottom))

                if (i == 0) {
                    path.moveTo(x, y)
                    fillPath.moveTo(x, height)
                    fillPath.lineTo(x, y)
                } else {
                    path.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }
            }

            fillPath.lineTo(width, height)
            fillPath.close()

            // Draw filled gradient area
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(gradientColor, Color.Transparent),
                    startY = 0f,
                    endY = height
                )
            )

            // Draw stroke line
            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // Draw last point dot
            val lastX = width
            val lastNorm = ((values.last() - minVal) / (maxVal - minVal)).coerceIn(0f, 1f)
            val lastY = height - (lastNorm * (height - paddingBottom))
            drawCircle(
                color = lineColor,
                radius = 5.dp.toPx(),
                center = Offset(lastX, lastY)
            )
        }

        // Time axis labels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
            val firstTs = points.firstOrNull()?.timestampMs ?: 0L
            val lastTs = points.lastOrNull()?.timestampMs ?: 0L
            Text(
                text = if (firstTs > 0) sdf.format(Date(firstTs)) else "--",
                style = MaterialTheme.typography.labelSmall,
                color = labelColor
            )
            Text(
                text = if (lastTs > 0) sdf.format(Date(lastTs)) else "--",
                style = MaterialTheme.typography.labelSmall,
                color = labelColor
            )
        }
    }
}
