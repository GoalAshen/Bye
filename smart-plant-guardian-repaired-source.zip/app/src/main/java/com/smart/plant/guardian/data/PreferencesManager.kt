package com.smart.plant.guardian.data

import android.content.Context
import android.content.SharedPreferences
import com.smart.plant.guardian.model.FirebaseConfig
import com.smart.plant.guardian.model.ThemeMode

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("smart_plant_guardian_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_DB_URL = "db_url"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_PROJECT_ID = "project_id"
        private const val KEY_APP_ID = "app_id"
        private const val KEY_EMAIL = "email"
        private const val PREF_LOGIN_PASSWORD = "password"
        private const val KEY_ID_TOKEN = "id_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_LOCAL_ID = "local_id"
        private const val KEY_TOKEN_EXPIRES = "token_expires"
        private const val KEY_THEME_MODE = "theme_mode"
        private const val KEY_SELECTED_DEVICE = "selected_device_id"
    }

    fun loadFirebaseConfig(): FirebaseConfig {
        return FirebaseConfig(
            databaseUrl = FirebaseConfig.BUILT_IN_DATABASE_URL,
            apiKey = FirebaseConfig.BUILT_IN_API_KEY,
            projectId = FirebaseConfig.BUILT_IN_PROJECT_ID,
            appId = FirebaseConfig.BUILT_IN_APP_ID,
            email = prefs.getString(KEY_EMAIL, "") ?: "",
            password = prefs.getString(PREF_LOGIN_PASSWORD, "") ?: "",
            idToken = prefs.getString(KEY_ID_TOKEN, "") ?: "",
            refreshToken = prefs.getString(KEY_REFRESH_TOKEN, "") ?: "",
            localId = prefs.getString(KEY_LOCAL_ID, "") ?: "",
            tokenExpiresEpochMs = prefs.getLong(KEY_TOKEN_EXPIRES, 0L)
        )
    }

    fun saveFirebaseConfig(config: FirebaseConfig) {
        prefs.edit()
            .putString(KEY_DB_URL, config.databaseUrl)
            .putString(KEY_API_KEY, config.apiKey)
            .putString(KEY_PROJECT_ID, config.projectId)
            .putString(KEY_APP_ID, config.appId)
            .putString(KEY_EMAIL, config.email)
            .putString(PREF_LOGIN_PASSWORD, config.password)
            .putString(KEY_ID_TOKEN, config.idToken)
            .putString(KEY_REFRESH_TOKEN, config.refreshToken)
            .putString(KEY_LOCAL_ID, config.localId)
            .putLong(KEY_TOKEN_EXPIRES, config.tokenExpiresEpochMs)
            .apply()
    }

    fun clearAuthTokens() {
        prefs.edit()
            .remove(KEY_ID_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_LOCAL_ID)
            .remove(KEY_TOKEN_EXPIRES)
            .apply()
    }

    fun loadThemeMode(): ThemeMode {
        val name = prefs.getString(KEY_THEME_MODE, ThemeMode.WALLPAPER.name)
        return try {
            ThemeMode.valueOf(name ?: ThemeMode.WALLPAPER.name)
        } catch (_: Exception) {
            ThemeMode.WALLPAPER
        }
    }

    fun saveThemeMode(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
    }

    fun loadSelectedDeviceId(): String? {
        return prefs.getString(KEY_SELECTED_DEVICE, null)
    }

    fun saveSelectedDeviceId(deviceId: String?) {
        prefs.edit().putString(KEY_SELECTED_DEVICE, deviceId).apply()
    }
}
