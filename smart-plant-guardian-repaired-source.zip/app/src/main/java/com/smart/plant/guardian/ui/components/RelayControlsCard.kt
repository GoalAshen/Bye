package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smart.plant.guardian.model.DeviceCommands
import com.smart.plant.guardian.model.DeviceStatus

@Composable
fun RelayControlsCard(
    deviceStatus: DeviceStatus?,
    deviceCommands: DeviceCommands?,
    isOperatorOrAdmin: Boolean,
    pendingCommandKey: String?,
    onSendCommand: (key: String, value: Any) -> Unit,
    modifier: Modifier = Modifier
) {
    val isPumpOn = deviceStatus?.isPumpOn == true
    val isAuto = deviceStatus?.isAuto == true
    val activeRunSec = deviceStatus?.activeRunSeconds

    val isPendingPump = pendingCommandKey?.contains(":pump:") == true
    val isPendingMode = pendingCommandKey?.contains(":mode:") == true

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("relay_controls_card"),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Card Title & Mode Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Irrigation Relay & Controls",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (!isOperatorOrAdmin) "Read-only (Viewer role)" else "Real device status",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // AUTO / MANUAL mode switch
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isAuto) "AUTO" else "MANUAL",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isAuto) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = isAuto,
                        onCheckedChange = { checked ->
                            if (isOperatorOrAdmin) {
                                onSendCommand("mode", if (checked) "AUTO" else "MANUAL")
                            }
                        },
                        enabled = isOperatorOrAdmin && !isPendingMode,
                        modifier = Modifier.testTag("mode_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Large Pump ON/OFF Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pump_status_surface"),
                shape = MaterialTheme.shapes.large,
                color = if (isPumpOn) {
                    MaterialTheme.colorScheme.primaryContainer
                } else {
                    MaterialTheme.colorScheme.surface
                },
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = if (isPumpOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                            modifier = Modifier.size(52.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.PowerSettingsNew,
                                    contentDescription = "Pump State",
                                    tint = if (isPumpOn) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "Water Pump Relay",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isPumpOn) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = when {
                                    isPendingPump -> "Awaiting confirmation…"
                                    isPumpOn -> "PUMP RUNNING${if (activeRunSec != null && activeRunSec > 0) " (${activeRunSec}s)" else ""}"
                                    else -> "PUMP IDLE (OFF)"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (isPumpOn) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (isPumpOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Pump Toggle Button
                    Button(
                        onClick = {
                            if (isOperatorOrAdmin) {
                                onSendCommand("pump", !isPumpOn)
                            }
                        },
                        enabled = isOperatorOrAdmin && !isPendingPump,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPumpOn) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.testTag("pump_toggle_button")
                    ) {
                        if (isPendingPump) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(if (isPumpOn) "TURN OFF" else "TURN ON")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Buzzer & Speaker Test
            Text(
                text = "Audio Feedback Test",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        if (isOperatorOrAdmin) {
                            onSendCommand("buzzer", true)
                        }
                    },
                    enabled = isOperatorOrAdmin,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("buzzer_test_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "Buzzer",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Beep Buzzer")
                }

                OutlinedButton(
                    onClick = {
                        if (isOperatorOrAdmin) {
                            onSendCommand("speaker", true)
                        }
                    },
                    enabled = isOperatorOrAdmin,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("speaker_test_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Speaker",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Test Speaker")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // LED Group Toggles (Red, Blue, Green, Yellow)
            Text(
                text = "Status LEDs Group",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val ledRed = deviceCommands?.ledRed == true
                val ledBlue = deviceCommands?.ledBlue == true
                val ledGreen = deviceCommands?.ledGreen == true
                val ledYellow = deviceCommands?.ledYellow == true

                FilterChip(
                    selected = ledRed,
                    onClick = { if (isOperatorOrAdmin) onSendCommand("ledRed", !ledRed) },
                    enabled = isOperatorOrAdmin,
                    label = { Text("Red") },
                    leadingIcon = {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(MaterialTheme.colorScheme.error, CircleShape)
                        )
                    },
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = ledBlue,
                    onClick = { if (isOperatorOrAdmin) onSendCommand("ledBlue", !ledBlue) },
                    enabled = isOperatorOrAdmin,
                    label = { Text("Blue") },
                    leadingIcon = {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(MaterialTheme.colorScheme.secondary, CircleShape)
                        )
                    },
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = ledGreen,
                    onClick = { if (isOperatorOrAdmin) onSendCommand("ledGreen", !ledGreen) },
                    enabled = isOperatorOrAdmin,
                    label = { Text("Green") },
                    leadingIcon = {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                        )
                    },
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = ledYellow,
                    onClick = { if (isOperatorOrAdmin) onSendCommand("ledYellow", !ledYellow) },
                    enabled = isOperatorOrAdmin,
                    label = { Text("Yellow") },
                    leadingIcon = {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(MaterialTheme.colorScheme.tertiary, CircleShape)
                        )
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
