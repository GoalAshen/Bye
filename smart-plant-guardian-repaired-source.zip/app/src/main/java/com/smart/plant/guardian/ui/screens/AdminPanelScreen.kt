package com.smart.plant.guardian.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smart.plant.guardian.model.AuditEntry
import com.smart.plant.guardian.model.Device
import com.smart.plant.guardian.model.DeviceSettings
import com.smart.plant.guardian.model.UserProfile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    users: List<UserProfile>,
    devices: Map<String, Device>,
    auditLogs: List<AuditEntry>,
    isLoading: Boolean,
    nowServerEpochMs: Long,
    onBack: () -> Unit,
    onRefreshAdminData: () -> Unit,
    onUpdateUser: (targetUid: String, role: String, status: String) -> Unit,
    onSetDeviceMember: (deviceId: String, memberUid: String, assigned: Boolean) -> Unit,
    onApplyGlobalThresholds: (DeviceSettings) -> Unit,
    onEmergencyAllPumpsOff: () -> Unit,
    onEmergencyForceManual: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Users", "Devices", "Thresholds", "Audit Log", "Emergency")

    LaunchedEffect(Unit) {
        onRefreshAdminData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Admin Shield",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Admin Panel", style = MaterialTheme.typography.titleLarge)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onRefreshAdminData, modifier = Modifier.testTag("admin_refresh_button")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }

            if (isLoading && users.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                when (selectedTab) {
                    0 -> UsersTab(users = users, onUpdateUser = onUpdateUser)
                    1 -> DevicesTab(devices = devices, users = users, nowServerEpochMs = nowServerEpochMs, onSetDeviceMember = onSetDeviceMember)
                    2 -> GlobalThresholdsTab(onApplyGlobalThresholds = onApplyGlobalThresholds)
                    3 -> AuditLogTab(auditLogs = auditLogs)
                    4 -> EmergencyTab(
                        onEmergencyAllPumpsOff = onEmergencyAllPumpsOff,
                        onEmergencyForceManual = onEmergencyForceManual
                    )
                }
            }
        }
    }
}

@Composable
private fun UsersTab(
    users: List<UserProfile>,
    onUpdateUser: (targetUid: String, role: String, status: String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterStatus by remember { mutableStateOf("ALL") }

    val filtered = remember(users, searchQuery, filterStatus) {
        users.filter { u ->
            val matchQuery = searchQuery.isBlank() ||
                    u.email.contains(searchQuery, ignoreCase = true) ||
                    u.displayName.contains(searchQuery, ignoreCase = true)
            val matchStatus = filterStatus == "ALL" || u.status.equals(filterStatus, ignoreCase = true)
            matchQuery && matchStatus
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search by email or name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ALL", "pending", "active", "blocked").forEach { st ->
                FilterChip(
                    selected = filterStatus == st,
                    onClick = { filterStatus = st },
                    label = { Text(st.uppercase()) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (filtered.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No users found.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(filtered, key = { it.uid }) { user ->
                    UserAdminCard(user = user, onUpdateUser = onUpdateUser)
                }
            }
        }
    }
}

@Composable
private fun UserAdminCard(
    user: UserProfile,
    onUpdateUser: (targetUid: String, role: String, status: String) -> Unit
) {
    var showRoleMenu by remember { mutableStateOf(false) }
    val availableRoles = listOf(
        UserProfile.ROLE_ADMIN,
        UserProfile.ROLE_OPERATOR,
        UserProfile.ROLE_VIEWER,
        UserProfile.ROLE_DEVICE // For ESP32 account role assignment!
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = user.email,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "UID: ${user.uid.take(12)}…",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Status chip
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = when {
                        user.isActive -> MaterialTheme.colorScheme.primaryContainer
                        user.isBlocked -> MaterialTheme.colorScheme.errorContainer
                        else -> MaterialTheme.colorScheme.tertiaryContainer
                    }
                ) {
                    Text(
                        text = user.status.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            user.isActive -> MaterialTheme.colorScheme.onPrimaryContainer
                            user.isBlocked -> MaterialTheme.colorScheme.onErrorContainer
                            else -> MaterialTheme.colorScheme.onTertiaryContainer
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Role selection & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Role Picker
                Box {
                    OutlinedButton(onClick = { showRoleMenu = true }) {
                        Text("Role: ${user.role.uppercase()}")
                    }
                    DropdownMenu(
                        expanded = showRoleMenu,
                        onDismissRequest = { showRoleMenu = false }
                    ) {
                        availableRoles.forEach { r ->
                            DropdownMenuItem(
                                text = { Text(r.uppercase()) },
                                onClick = {
                                    onUpdateUser(user.uid, r, user.status)
                                    showRoleMenu = false
                                }
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Approve button if pending
                    if (user.isPending) {
                        Button(
                            onClick = { onUpdateUser(user.uid, user.role, UserProfile.STATUS_ACTIVE) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Approve")
                        }
                    }

                    // Block / Unblock Button
                    OutlinedButton(
                        onClick = {
                            val nextStatus = if (user.isBlocked) UserProfile.STATUS_ACTIVE else UserProfile.STATUS_BLOCKED
                            onUpdateUser(user.uid, user.role, nextStatus)
                        }
                    ) {
                        Text(if (user.isBlocked) "Unblock" else "Block")
                    }
                }
            }
        }
    }
}

@Composable
private fun DevicesTab(
    devices: Map<String, Device>,
    users: List<UserProfile>,
    nowServerEpochMs: Long,
    onSetDeviceMember: (deviceId: String, memberUid: String, assigned: Boolean) -> Unit
) {
    if (devices.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("No devices registered in Firebase yet.", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(devices.values.toList(), key = { it.id }) { dev ->
            val isOnline = dev.isOnline(nowServerEpochMs)
            var showMembersSheet by remember { mutableStateOf(false) }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = dev.displayName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Device ID: ${dev.id}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Online / Offline
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = if (isOnline) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                        ) {
                            Text(
                                text = if (isOnline) "ONLINE" else "OFFLINE",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isOnline) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Battery: ${dev.sensors?.batteryPercent?.let { "$it%" } ?: "--"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Last seen: ${dev.sensors?.lastSeenEpochMs?.let { "${(nowServerEpochMs - it)/1000}s ago" } ?: "--"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Members: ${dev.members.size}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { showMembersSheet = !showMembersSheet },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (showMembersSheet) "Hide Assigned Members" else "Manage Assigned Members")
                    }

                    if (showMembersSheet) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Assign users to /devices/${dev.id}/members:", style = MaterialTheme.typography.labelSmall)
                        Spacer(modifier = Modifier.height(6.dp))
                        users.forEach { u ->
                            val isMember = dev.members[u.uid] == true
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isMember,
                                    onCheckedChange = { checked ->
                                        onSetDeviceMember(dev.id, u.uid, checked)
                                    }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(u.email, style = MaterialTheme.typography.bodyMedium)
                                    Text("Role: ${u.role}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GlobalThresholdsTab(
    onApplyGlobalThresholds: (DeviceSettings) -> Unit
) {
    var dryPct by remember { mutableIntStateOf(30) }
    var targetPct by remember { mutableIntStateOf(65) }
    var highTemp by remember { mutableFloatStateOf(35f) }
    var lowBatt by remember { mutableIntStateOf(20) }
    var maxPumpRun by remember { mutableIntStateOf(15) }
    var showConfirmDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Global Default Thresholds",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Set baseline thresholds and push them to all auto-discovered ESP32 units at once.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Soil Dry: $dryPct%", fontWeight = FontWeight.SemiBold)
                Slider(value = dryPct.toFloat(), onValueChange = { dryPct = it.roundToInt() }, valueRange = 10f..60f)

                Text("Soil Target: $targetPct%", fontWeight = FontWeight.SemiBold)
                Slider(value = targetPct.toFloat(), onValueChange = { targetPct = it.roundToInt() }, valueRange = 40f..90f)

                Text("High Temp Alert: ${String.format("%.1f", highTemp)}°C", fontWeight = FontWeight.SemiBold)
                Slider(value = highTemp, onValueChange = { highTemp = it }, valueRange = 25f..50f)

                Text("Low Battery Alert: $lowBatt%", fontWeight = FontWeight.SemiBold)
                Slider(value = lowBatt.toFloat(), onValueChange = { lowBatt = it.roundToInt() }, valueRange = 5f..40f)

                Text("Max Pump Run: $maxPumpRun min", fontWeight = FontWeight.SemiBold)
                Slider(value = maxPumpRun.toFloat(), onValueChange = { maxPumpRun = it.roundToInt() }, valueRange = 1f..60f)
            }
        }

        Button(
            onClick = { showConfirmDialog = true },
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("Apply to All Devices")
        }
    }

    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            title = { Text("Confirm Global Thresholds") },
            text = { Text("Are you sure you want to apply these default thresholds to ALL connected ESP32 devices?") },
            confirmButton = {
                Button(onClick = {
                    val s = DeviceSettings(
                        soilDryPercent = dryPct,
                        soilTargetPercent = targetPct,
                        highTempAlertThresholdC = highTemp,
                        lowBatteryAlertPercent = lowBatt,
                        maxPumpRunTimeMinutes = maxPumpRun
                    )
                    onApplyGlobalThresholds(s)
                    showConfirmDialog = false
                }) {
                    Text("Apply All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun AuditLogTab(auditLogs: List<AuditEntry>) {
    var searchFilter by remember { mutableStateOf("") }
    val filteredLogs = remember(auditLogs, searchFilter) {
        if (searchFilter.isBlank()) auditLogs
        else auditLogs.filter {
            it.action.contains(searchFilter, ignoreCase = true) ||
                    it.email.contains(searchFilter, ignoreCase = true) ||
                    it.deviceId.contains(searchFilter, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = searchFilter,
            onValueChange = { searchFilter = it },
            label = { Text("Filter audit log by action, email, or device") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredLogs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No activity log entries found.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filteredLogs, key = { it.id.ifBlank { it.timestampMs.toString() } }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = item.action,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (item.timestampMs > 0) sdf.format(Date(item.timestampMs)) else "--",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "By: ${item.email.ifBlank { item.uid }} • Target: ${item.deviceId}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (item.details.isNotBlank()) {
                                Text(
                                    text = item.details,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmergencyTab(
    onEmergencyAllPumpsOff: () -> Unit,
    onEmergencyForceManual: () -> Unit
) {
    var showPumpsOffDialog by remember { mutableStateOf(false) }
    var showForceManualDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Emergency",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "Emergency Override Controls",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.error
            )
        }

        Text(
            text = "Emergency actions immediately broadcast commands to all connected ESP32 irrigation units and log an audit trail.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Emergency: All Pumps OFF",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Immediately shuts off all active irrigation relays to prevent flooding or tank depletion.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = { showPumpsOffDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth().testTag("emergency_all_pumps_off_button")
                ) {
                    Text("EMERGENCY: ALL PUMPS OFF")
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Emergency: Force MANUAL Mode",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Forces every ESP32 device into MANUAL mode, disabling all automated threshold and timer watering.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = { showForceManualDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                    modifier = Modifier.fillMaxWidth().testTag("emergency_force_manual_button")
                ) {
                    Text("FORCE MANUAL ON ALL DEVICES")
                }
            }
        }
    }

    if (showPumpsOffDialog) {
        AlertDialog(
            onDismissRequest = { showPumpsOffDialog = false },
            title = { Text("Confirm Emergency Action") },
            text = { Text("Are you sure you want to turn OFF all irrigation pumps on all devices right now?") },
            confirmButton = {
                Button(
                    onClick = {
                        onEmergencyAllPumpsOff()
                        showPumpsOffDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Yes, Turn All OFF")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPumpsOffDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showForceManualDialog) {
        AlertDialog(
            onDismissRequest = { showForceManualDialog = false },
            title = { Text("Confirm Force MANUAL") },
            text = { Text("Are you sure you want to force MANUAL mode across all connected devices?") },
            confirmButton = {
                Button(
                    onClick = {
                        onEmergencyForceManual()
                        showForceManualDialog = false
                    }
                ) {
                    Text("Yes, Force MANUAL")
                }
            },
            dismissButton = {
                TextButton(onClick = { showForceManualDialog = false }) { Text("Cancel") }
            }
        )
    }
}
