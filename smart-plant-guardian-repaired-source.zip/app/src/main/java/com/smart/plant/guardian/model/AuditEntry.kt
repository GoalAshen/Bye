package com.smart.plant.guardian.model

data class AuditEntry(
    val id: String = "",
    val uid: String = "",
    val email: String = "",
    val action: String = "",
    val deviceId: String = "",
    val timestampMs: Long = 0L,
    val details: String = ""
)
