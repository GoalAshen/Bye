package com.smart.plant.guardian.model

data class DeviceMeta(
    val name: String? = null,
    val locationName: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val firmwareVersion: String? = null,
    val wifiSsid: String? = null,
    val ipAddress: String? = null
)

data class DeviceSensors(
    val temperatureC: Float? = null,
    val humidityPercent: Float? = null,
    val soilZone1: Int? = null, // 0 - 100
    val soilZone2: Int? = null, // 0 - 100
    val soilZone3: Int? = null, // 0 - 100
    val lightPercent: Int? = null, // 0 - 100
    val isRaining: Boolean? = null,
    val batteryPercent: Int? = null, // 0 - 100 only
    val solarCharging: Boolean? = null, // optional, hide if missing
    val lastSeenEpochMs: Long? = null
)

data class DeviceStatus(
    val pumpOn: Boolean? = null,
    val mode: String? = null, // "AUTO" or "MANUAL"
    val activeRunSeconds: Int? = null
) {
    val isPumpOn: Boolean get() = pumpOn == true
    val isAuto: Boolean get() = mode?.equals("AUTO", ignoreCase = true) == true
    val isManual: Boolean get() = mode?.equals("MANUAL", ignoreCase = true) == true
}

data class DeviceCommands(
    val power: Boolean? = null,
    val pump: Boolean? = null,
    val mode: String? = null, // "AUTO" / "MANUAL"
    val buzzer: Boolean? = null,
    val speaker: Boolean? = null,
    val ledRed: Boolean? = null,
    val ledBlue: Boolean? = null,
    val ledGreen: Boolean? = null,
    val ledYellow: Boolean? = null
)

data class ScheduleSettings(
    val enabled: Boolean = false,
    val startHour: Int = 6,
    val startMinute: Int = 0,
    val durationMinutes: Int = 10,
    val activeDays: List<Int> = listOf(1, 2, 3, 4, 5, 6, 7) // 1=Mon .. 7=Sun or day indexes
)

data class DeviceSettings(
    val soilDryPercent: Int = 30,
    val soilTargetPercent: Int = 65,
    val highTempAlertThresholdC: Float = 35.0f,
    val lowBatteryAlertPercent: Int = 20,
    val maxPumpRunTimeMinutes: Int = 15,
    val schedule: ScheduleSettings = ScheduleSettings()
)

data class HistoryPoint(
    val pushId: String = "",
    val timestampMs: Long = 0L,
    val tempC: Float? = null,
    val humidity: Float? = null,
    val soilAvg: Float? = null,
    val zone1: Int? = null,
    val zone2: Int? = null,
    val zone3: Int? = null,
    val lightPercent: Int? = null,
    val batteryPercent: Int? = null
)

data class Device(
    val id: String,
    val meta: DeviceMeta? = null,
    val sensors: DeviceSensors? = null,
    val status: DeviceStatus? = null,
    val commands: DeviceCommands? = null,
    val settings: DeviceSettings = DeviceSettings(),
    val members: Map<String, Boolean> = emptyMap(),
    val history: List<HistoryPoint> = emptyList()
) {
    val displayName: String
        get() = meta?.name?.takeIf { it.isNotBlank() } ?: id

    /**
     * Calculates whether the device is online based on server-synchronized epoch time.
     * Offline if lastSeenEpochMs is older than 60 seconds (60,000 ms).
     */
    fun isOnline(nowServerEpochMs: Long): Boolean {
        val lastSeen = sensors?.lastSeenEpochMs ?: return false
        if (lastSeen <= 0L) return false
        val diffMs = nowServerEpochMs - lastSeen
        return diffMs in -10000L..60000L // Allow small positive margin and up to 60s past
    }

    /**
     * Light level classification: Dark (< 20%), Dim (20-60%), Bright (> 60%)
     */
    val lightClassification: String
        get() {
            val light = sensors?.lightPercent ?: return "--"
            return when {
                light < 20 -> "Dark ($light%)"
                light <= 60 -> "Dim ($light%)"
                else -> "Bright ($light%)"
            }
        }
}
