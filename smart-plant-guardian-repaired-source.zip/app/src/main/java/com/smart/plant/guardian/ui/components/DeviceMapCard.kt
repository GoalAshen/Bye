package com.smart.plant.guardian.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smart.plant.guardian.model.DeviceMeta

@Composable
fun DeviceMapCard(
    meta: DeviceMeta?,
    deviceId: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lat = meta?.latitude
    val lng = meta?.longitude
    val locationName = meta?.locationName ?: "Registered Field Location"
    val hasCoords = lat != null && lng != null

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("device_map_card"),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Device Location",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Device Location & Metadata",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (hasCoords) {
                    OutlinedButton(
                        onClick = {
                            val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng($locationName)")
                            val mapIntent = Intent(Intent.ACTION_VIEW, uri)
                            context.startActivity(mapIntent)
                        },
                        modifier = Modifier.testTag("open_map_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Map,
                            contentDescription = "Map",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open Map")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Map preview Canvas (Radar/Pin visualization)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp
            ) {
                val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)
                val primaryColor = MaterialTheme.colorScheme.primary
                val onPrimaryColor = MaterialTheme.colorScheme.onPrimary
                val secondaryColor = MaterialTheme.colorScheme.secondary

                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxWidth().height(130.dp)) {
                        val w = size.width
                        val h = size.height

                        // Draw coordinate radar grid
                        val step = 28f
                        var x = 0f
                        while (x <= w) {
                            drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
                            x += step
                        }
                        var y = 0f
                        while (y <= h) {
                            drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                            y += step
                        }

                        // Concentric rings
                        val center = Offset(w / 2f, h / 2f)
                        drawCircle(secondaryColor.copy(alpha = 0.15f), radius = 50f, center = center)
                        drawCircle(secondaryColor.copy(alpha = 0.1f), radius = 90f, center = center)

                        // Center pin indicator
                        drawCircle(primaryColor, radius = 9f, center = center)
                        drawCircle(onPrimaryColor, radius = 3.5f, center = center)
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Text(
                            text = locationName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (hasCoords) "GPS: ${String.format("%.4f", lat)}, ${String.format("%.4f", lng)}" else "GPS Coordinates: --",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Device Technical Metadata Grid (firmwareVersion, wifiSsid, ipAddress)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetaInfoBadge(
                    label = "Firmware",
                    value = meta?.firmwareVersion ?: "--"
                )
                MetaInfoBadge(
                    label = "WiFi SSID",
                    value = meta?.wifiSsid ?: "--"
                )
                MetaInfoBadge(
                    label = "IP Address",
                    value = meta?.ipAddress ?: "--"
                )
            }
        }
    }
}

@Composable
private fun MetaInfoBadge(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
