package com.smart.plant.guardian.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.smart.plant.guardian.model.ThemeMode

val FixedGreenLightColorScheme = lightColorScheme(
    primary = GreenPrimaryLight,
    onPrimary = GreenOnPrimaryLight,
    primaryContainer = GreenPrimaryContainerLight,
    onPrimaryContainer = GreenOnPrimaryContainerLight,
    secondary = AquaSecondaryLight,
    onSecondary = AquaOnSecondaryLight,
    secondaryContainer = AquaSecondaryContainerLight,
    onSecondaryContainer = AquaOnSecondaryContainerLight,
    tertiary = TerraTertiaryLight,
    onTertiary = TerraOnTertiaryLight,
    tertiaryContainer = TerraTertiaryContainerLight,
    onTertiaryContainer = TerraOnTertiaryContainerLight,
    background = GreenBackgroundLight,
    onBackground = GreenOnBackgroundLight,
    surface = GreenSurfaceLight,
    onSurface = GreenOnSurfaceLight,
    surfaceVariant = GreenSurfaceVariantLight,
    onSurfaceVariant = GreenOnSurfaceVariantLight,
    outline = GreenOutlineLight
)

val FixedGreenDarkColorScheme = darkColorScheme(
    primary = GreenPrimaryDark,
    onPrimary = GreenOnPrimaryDark,
    primaryContainer = GreenPrimaryContainerDark,
    onPrimaryContainer = GreenOnPrimaryContainerDark,
    secondary = AquaSecondaryDark,
    onSecondary = AquaOnSecondaryDark,
    secondaryContainer = AquaSecondaryContainerDark,
    onSecondaryContainer = AquaOnSecondaryContainerContainerDark,
    tertiary = TerraTertiaryDark,
    onTertiary = TerraOnTertiaryDark,
    tertiaryContainer = TerraTertiaryContainerDark,
    onTertiaryContainer = TerraOnTertiaryContainerDark,
    background = GreenBackgroundDark,
    onBackground = GreenOnBackgroundDark,
    surface = GreenSurfaceDark,
    onSurface = GreenOnSurfaceDark,
    surfaceVariant = GreenSurfaceVariantDark,
    onSurfaceVariant = GreenOnSurfaceVariantDark,
    outline = GreenOutlineDark
)

val PlantGuardianShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SmartPlantGuardianTheme(
    themeMode: ThemeMode = ThemeMode.WALLPAPER,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val systemInDark = isSystemInDarkTheme()

    val isDark = when (themeMode) {
        ThemeMode.WALLPAPER, ThemeMode.SYSTEM -> systemInDark
        ThemeMode.FIXED_GREEN -> systemInDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = when {
        // Material You wallpaper dynamic color on Android 12+ (API 31+)
        themeMode == ThemeMode.WALLPAPER && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        isDark -> FixedGreenDarkColorScheme
        else -> FixedGreenLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = PlantGuardianShapes,
        content = content
    )
}
