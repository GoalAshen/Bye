package com.smart.plant.guardian.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smart.plant.guardian.data.AuthResult
import com.smart.plant.guardian.data.FirebaseClient
import com.smart.plant.guardian.data.NotificationHelper
import com.smart.plant.guardian.data.PreferencesManager
import com.smart.plant.guardian.model.AuditEntry
import com.smart.plant.guardian.model.Device
import com.smart.plant.guardian.model.DeviceSettings
import com.smart.plant.guardian.model.FirebaseConfig
import com.smart.plant.guardian.model.HistoryPoint
import com.smart.plant.guardian.model.ThemeMode
import com.smart.plant.guardian.model.UserProfile
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class UiMessage(
    val id: Long = System.currentTimeMillis(),
    val text: String,
    val isError: Boolean = false
)

class PlantGuardianViewModel(application: Application) : AndroidViewModel(application) {

    private val preferencesManager = PreferencesManager(application)
    private val firebaseClient = FirebaseClient(preferencesManager)
    private val notificationHelper = NotificationHelper(application)

    // Firebase Config State
    private val _config = MutableStateFlow(preferencesManager.loadFirebaseConfig())
    val config: StateFlow<FirebaseConfig> = _config.asStateFlow()

    // Auth & User Profile State
    private val _userProfile = MutableStateFlow<UserProfile?>(null)
    val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    // Devices & Telemetry State
    private val _devices = MutableStateFlow<Map<String, Device>>(emptyMap())
    val devices: StateFlow<Map<String, Device>> = _devices.asStateFlow()

    private val _selectedDeviceId = MutableStateFlow<String?>(preferencesManager.loadSelectedDeviceId())
    val selectedDeviceId: StateFlow<String?> = _selectedDeviceId.asStateFlow()

    // Server time offset (.info/serverTimeOffset)
    private val _serverTimeOffsetMs = MutableStateFlow(0L)
    val serverTimeOffsetMs: StateFlow<Long> = _serverTimeOffsetMs.asStateFlow()

    // Current synchronized server time
    private val _currentServerTimeMs = MutableStateFlow(System.currentTimeMillis())
    val currentServerTimeMs: StateFlow<Long> = _currentServerTimeMs.asStateFlow()

    // Command in-flight tracking (10-second confirmation timeout)
    private val _pendingCommandKey = MutableStateFlow<String?>(null)
    val pendingCommandKey: StateFlow<String?> = _pendingCommandKey.asStateFlow()

    // UI Snackbars / Banners
    private val _uiMessage = MutableStateFlow<UiMessage?>(null)
    val uiMessage: StateFlow<UiMessage?> = _uiMessage.asStateFlow()

    // Admin Panel State
    private val _allUsers = MutableStateFlow<List<UserProfile>>(emptyList())
    val allUsers: StateFlow<List<UserProfile>> = _allUsers.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditEntry>>(emptyList())
    val auditLogs: StateFlow<List<AuditEntry>> = _auditLogs.asStateFlow()

    private val _isAdminLoading = MutableStateFlow(false)
    val isAdminLoading: StateFlow<Boolean> = _isAdminLoading.asStateFlow()

    // Theme Mode
    private val _themeMode = MutableStateFlow(preferencesManager.loadThemeMode())
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // Jobs
    private var streamJob: Job? = null
    private var watchdogJob: Job? = null
    private var commandTimeoutJob: Job? = null

    // Track previous device online states to notify on transition
    private val previousOnlineState = mutableMapOf<String, Boolean>()

    init {
        startWatchdog()
        // Auto sign-in if credentials or tokens are saved
        val currentCfg = _config.value
        if (currentCfg.isConfigured && currentCfg.email.isNotBlank() && currentCfg.password.isNotBlank()) {
            signIn(currentCfg)
        }
    }

    fun updateConfigDraft(
        databaseUrl: String,
        apiKey: String,
        projectId: String,
        appId: String,
        email: String,
        password: String
    ) {
        val updated = _config.value.copy(
            databaseUrl = databaseUrl,
            apiKey = apiKey,
            projectId = projectId,
            appId = appId,
            email = email,
            password = password
        )
        _config.value = updated
        preferencesManager.saveFirebaseConfig(updated)
    }

    fun clearAuthError() {
        _authError.value = null
    }

    fun clearUiMessage() {
        _uiMessage.value = null
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        preferencesManager.saveThemeMode(mode)
    }

    fun selectDevice(deviceId: String) {
        _selectedDeviceId.value = deviceId
        preferencesManager.saveSelectedDeviceId(deviceId)
        fetchDeviceHistory(deviceId)
    }

    fun signIn(customConfig: FirebaseConfig? = null) {
        val cfg = customConfig ?: _config.value
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null

            when (val result = firebaseClient.signIn(cfg)) {
                is AuthResult.Success -> {
                    _config.value = result.config
                    _userProfile.value = result.userProfile
                    onAuthSuccess(result.config)
                }
                is AuthResult.Error -> {
                    _authError.value = result.message
                }
            }
            _isAuthLoading.value = false
        }
    }

    fun register(customConfig: FirebaseConfig? = null) {
        val cfg = customConfig ?: _config.value
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null

            when (val result = firebaseClient.register(cfg)) {
                is AuthResult.Success -> {
                    _config.value = result.config
                    _userProfile.value = result.userProfile
                    onAuthSuccess(result.config)
                }
                is AuthResult.Error -> {
                    _authError.value = result.message
                }
            }
            _isAuthLoading.value = false
        }
    }

    fun checkUserStatus() {
        val profile = _userProfile.value ?: return
        viewModelScope.launch {
            _isAuthLoading.value = true
            val refreshed = firebaseClient.fetchUserProfile(_config.value, profile.uid)
            if (refreshed != null) {
                _userProfile.value = refreshed
                if (refreshed.isActive) {
                    onAuthSuccess(_config.value)
                } else if (refreshed.isBlocked) {
                    _uiMessage.value = UiMessage(text = "Access disabled by administrator.", isError = true)
                } else {
                    _uiMessage.value = UiMessage(text = "Still pending approval by administrator.")
                }
            } else {
                _uiMessage.value = UiMessage(text = "Could not verify profile from Firebase.", isError = true)
            }
            _isAuthLoading.value = false
        }
    }

    fun signOut() {
        preferencesManager.clearAuthTokens()
        _config.update { it.copy(idToken = "", refreshToken = "", localId = "") }
        _userProfile.value = null
        _devices.value = emptyMap()
        streamJob?.cancel()
        streamJob = null
    }

    private fun onAuthSuccess(config: FirebaseConfig) {
        viewModelScope.launch {
            val offset = firebaseClient.fetchServerTimeOffset(config)
            _serverTimeOffsetMs.value = offset
            _currentServerTimeMs.value = System.currentTimeMillis() + offset
            startDevicesStream()
        }
    }

    private fun startDevicesStream() {
        streamJob?.cancel()
        streamJob = viewModelScope.launch {
            firebaseClient.streamDevices(_config.value, _userProfile.value).collectLatest { updatedDevices ->
                _devices.value = updatedDevices

                // Auto-select device if none selected or previous selection disappeared
                val currentSelected = _selectedDeviceId.value
                if (currentSelected == null || !updatedDevices.containsKey(currentSelected)) {
                    val firstKey = updatedDevices.keys.firstOrNull()
                    _selectedDeviceId.value = firstKey
                    preferencesManager.saveSelectedDeviceId(firstKey)
                    firstKey?.let { fetchDeviceHistory(it) }
                }

                // Check pending command response
                checkPendingCommandConfirmation(updatedDevices)
            }
        }
    }

    fun refreshDevicesManually() {
        viewModelScope.launch {
            val devs = firebaseClient.fetchAllDevices(_config.value, _userProfile.value)
            _devices.value = devs
            checkPendingCommandConfirmation(devs)
        }
    }

    fun fetchDeviceHistory(deviceId: String) {
        viewModelScope.launch {
            val history = firebaseClient.fetchDeviceHistory(_config.value, deviceId)
            _devices.update { map ->
                val dev = map[deviceId] ?: return@update map
                map + (deviceId to dev.copy(history = history))
            }
        }
    }

    /**
     * Send command to ESP32: power, pump, mode, buzzer, speaker, ledRed, etc.
     * The app shows the real device state from /status (not the local switch).
     * If a command is not confirmed within 10 seconds, show "Device did not respond".
     */
    fun sendDeviceCommand(deviceId: String, commandKey: String, commandValue: Any) {
        val user = _userProfile.value
        if (user == null || !user.isOperator) {
            _uiMessage.value = UiMessage(text = "Viewers are read-only. Operator role required.", isError = true)
            return
        }

        viewModelScope.launch {
            val success = firebaseClient.sendCommand(_config.value, deviceId, commandKey, commandValue)
            if (success) {
                // Record pending confirmation tracking
                val trackerId = "$deviceId:$commandKey:$commandValue"
                _pendingCommandKey.value = trackerId

                // Write audit entry
                firebaseClient.writeAudit(
                    _config.value,
                    AuditEntry(
                        uid = user.uid,
                        email = user.email,
                        action = "COMMAND_$commandKey",
                        deviceId = deviceId,
                        details = "Sent $commandKey=$commandValue"
                    )
                )

                // Start 10-second timeout watchdog for this command
                commandTimeoutJob?.cancel()
                commandTimeoutJob = viewModelScope.launch {
                    delay(10_000L)
                    if (_pendingCommandKey.value == trackerId) {
                        _pendingCommandKey.value = null
                        _uiMessage.value = UiMessage(text = "Device did not respond to $commandKey command.", isError = true)
                    }
                }
            } else {
                _uiMessage.value = UiMessage(text = "Failed to send command. Check permissions.", isError = true)
            }
        }
    }

    private fun checkPendingCommandConfirmation(currentDevices: Map<String, Device>) {
        val pending = _pendingCommandKey.value ?: return
        val parts = pending.split(':')
        if (parts.size < 3) return
        val devId = parts[0]
        val key = parts[1]
        val expectedVal = parts[2]

        val dev = currentDevices[devId] ?: return
        val status = dev.status ?: return

        val confirmed = when (key) {
            "pump" -> status.isPumpOn == expectedVal.toBooleanStrictOrNull()
            "mode" -> status.mode.equals(expectedVal, ignoreCase = true)
            else -> true // Instant commands like buzzer test confirm immediately on acknowledge
        }

        if (confirmed) {
            _pendingCommandKey.value = null
            commandTimeoutJob?.cancel()
        }
    }

    /**
     * Update Device Settings
     */
    fun updateSettings(deviceId: String, settings: DeviceSettings) {
        val user = _userProfile.value
        if (user == null || !user.isOperator) {
            _uiMessage.value = UiMessage(text = "Operator or Admin role required.", isError = true)
            return
        }

        viewModelScope.launch {
            val success = firebaseClient.updateDeviceSettings(_config.value, deviceId, settings)
            if (success) {
                _uiMessage.value = UiMessage(text = "Settings applied successfully.")
                firebaseClient.writeAudit(
                    _config.value,
                    AuditEntry(
                        uid = user.uid,
                        email = user.email,
                        action = "UPDATE_SETTINGS",
                        deviceId = deviceId,
                        details = "Dry:${settings.soilDryPercent}% Target:${settings.soilTargetPercent}% Temp:${settings.highTempAlertThresholdC}C"
                    )
                )
            } else {
                _uiMessage.value = UiMessage(text = "Failed to update settings.", isError = true)
            }
        }
    }

    // 5-second Watchdog: updates server time, evaluates alerts even without new data
    private fun startWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = viewModelScope.launch {
            while (isActive) {
                delay(5000L)
                val currentSynced = System.currentTimeMillis() + _serverTimeOffsetMs.value
                _currentServerTimeMs.value = currentSynced
                evaluateAlertsAndWatchdog(currentSynced)
            }
        }
    }

    private fun evaluateAlertsAndWatchdog(nowEpochMs: Long) {
        val currentDevs = _devices.value
        val user = _userProfile.value ?: return
        if (!user.isActive) return

        var notificationIndex = 1
        for ((devId, dev) in currentDevs) {
            val isOnline = dev.isOnline(nowEpochMs)
            val wasOnline = previousOnlineState[devId] ?: true
            previousOnlineState[devId] = isOnline

            // Offline alert on state transition
            if (!isOnline && wasOnline) {
                notificationHelper.sendAlert(
                    devId,
                    "offline",
                    "Device Offline: ${dev.displayName}",
                    "Smart Plant Guardian lost telemetry from ${dev.displayName}.",
                    notificationIndex++
                )
            }

            // Sensor-based alerts only if device is currently online and has sensor data
            if (isOnline) {
                val sensors = dev.sensors
                val settings = dev.settings

                if (sensors != null) {
                    // 1. Dry soil alert: any zone < settings.soilDryPercent
                    val z1 = sensors.soilZone1
                    val z2 = sensors.soilZone2
                    val z3 = sensors.soilZone3
                    val isDry = (z1 != null && z1 < settings.soilDryPercent) ||
                            (z2 != null && z2 < settings.soilDryPercent) ||
                            (z3 != null && z3 < settings.soilDryPercent)

                    if (isDry) {
                        notificationHelper.sendAlert(
                            devId,
                            "dry_soil",
                            "Dry Soil Alert: ${dev.displayName}",
                            "Soil moisture dropped below target (${settings.soilDryPercent}%). Needs water!",
                            notificationIndex++
                        )
                    }

                    // 2. High temperature alert
                    val temp = sensors.temperatureC
                    if (temp != null && temp > settings.highTempAlertThresholdC) {
                        notificationHelper.sendAlert(
                            devId,
                            "high_temp",
                            "High Temperature Alert: ${dev.displayName}",
                            "Temperature reached ${String.format("%.1f", temp)}°C (threshold ${settings.highTempAlertThresholdC}°C)!",
                            notificationIndex++
                        )
                    }

                    // 3. Rain alert
                    if (sensors.isRaining == true) {
                        notificationHelper.sendAlert(
                            devId,
                            "rain",
                            "Rain Detected: ${dev.displayName}",
                            "Rain sensor triggered outdoors at ${dev.displayName}.",
                            notificationIndex++
                        )
                    }

                    // 4. Low battery alert
                    val batt = sensors.batteryPercent
                    if (batt != null && batt < settings.lowBatteryAlertPercent) {
                        notificationHelper.sendAlert(
                            devId,
                            "low_battery",
                            "Low Battery: ${dev.displayName}",
                            "Battery level is at $batt% (below ${settings.lowBatteryAlertPercent}%).",
                            notificationIndex++
                        )
                    }
                }
            }
        }
    }

    // Admin Panel Methods
    fun loadAdminData() {
        val user = _userProfile.value
        if (user == null || !user.isAdmin) return

        viewModelScope.launch {
            _isAdminLoading.value = true
            val users = firebaseClient.fetchAllUsers(_config.value)
            _allUsers.value = users
            val logs = firebaseClient.fetchAuditLog(_config.value)
            _auditLogs.value = logs
            _isAdminLoading.value = false
        }
    }

    fun adminUpdateUser(targetUid: String, role: String, status: String) {
        val admin = _userProfile.value ?: return
        if (!admin.isAdmin) return

        viewModelScope.launch {
            _isAdminLoading.value = true
            val success = firebaseClient.updateUserRoleAndStatus(_config.value, targetUid, role, status)
            if (success) {
                _uiMessage.value = UiMessage(text = "User updated ($role, $status).")
                firebaseClient.writeAudit(
                    _config.value,
                    AuditEntry(
                        uid = admin.uid,
                        email = admin.email,
                        action = "ADMIN_UPDATE_USER",
                        deviceId = "system",
                        details = "Target: $targetUid -> role=$role status=$status"
                    )
                )
                loadAdminData()
            } else {
                _uiMessage.value = UiMessage(text = "Failed to update user.", isError = true)
                _isAdminLoading.value = false
            }
        }
    }

    fun adminSetDeviceMember(deviceId: String, memberUid: String, assigned: Boolean) {
        val admin = _userProfile.value ?: return
        if (!admin.isAdmin) return

        viewModelScope.launch {
            val success = firebaseClient.setDeviceMember(_config.value, deviceId, memberUid, assigned)
            if (success) {
                _uiMessage.value = UiMessage(text = if (assigned) "Member added to $deviceId." else "Member removed from $deviceId.")
                refreshDevicesManually()
            } else {
                _uiMessage.value = UiMessage(text = "Failed to update member.", isError = true)
            }
        }
    }

    fun adminApplyGlobalThresholds(settings: DeviceSettings) {
        val admin = _userProfile.value ?: return
        if (!admin.isAdmin) return

        viewModelScope.launch {
            _isAdminLoading.value = true
            val devs = _devices.value
            var successCount = 0
            for ((id, _) in devs) {
                if (firebaseClient.updateDeviceSettings(_config.value, id, settings)) {
                    successCount++
                }
            }
            firebaseClient.writeAudit(
                _config.value,
                AuditEntry(
                    uid = admin.uid,
                    email = admin.email,
                    action = "ADMIN_GLOBAL_THRESHOLDS",
                    deviceId = "all",
                    details = "Applied to $successCount/${devs.size} devices"
                )
            )
            _uiMessage.value = UiMessage(text = "Global thresholds applied to $successCount devices.")
            _isAdminLoading.value = false
            refreshDevicesManually()
        }
    }

    fun adminEmergencyAllPumpsOff() {
        val admin = _userProfile.value ?: return
        if (!admin.isAdmin) return

        viewModelScope.launch {
            _isAdminLoading.value = true
            val devs = _devices.value
            var count = 0
            for ((id, _) in devs) {
                if (firebaseClient.sendCommand(_config.value, id, "pump", false)) {
                    count++
                }
            }
            firebaseClient.writeAudit(
                _config.value,
                AuditEntry(
                    uid = admin.uid,
                    email = admin.email,
                    action = "EMERGENCY_ALL_PUMPS_OFF",
                    deviceId = "all",
                    details = "Turned OFF pumps on $count devices"
                )
            )
            _uiMessage.value = UiMessage(text = "Emergency: Turned OFF pumps on $count devices.", isError = true)
            _isAdminLoading.value = false
            refreshDevicesManually()
        }
    }

    fun adminEmergencyForceManual() {
        val admin = _userProfile.value ?: return
        if (!admin.isAdmin) return

        viewModelScope.launch {
            _isAdminLoading.value = true
            val devs = _devices.value
            var count = 0
            for ((id, _) in devs) {
                if (firebaseClient.sendCommand(_config.value, id, "mode", "MANUAL")) {
                    count++
                }
            }
            firebaseClient.writeAudit(
                _config.value,
                AuditEntry(
                    uid = admin.uid,
                    email = admin.email,
                    action = "EMERGENCY_FORCE_MANUAL",
                    deviceId = "all",
                    details = "Forced MANUAL mode on $count devices"
                )
            )
            _uiMessage.value = UiMessage(text = "Emergency: Forced MANUAL on $count devices.")
            _isAdminLoading.value = false
            refreshDevicesManually()
        }
    }
}
