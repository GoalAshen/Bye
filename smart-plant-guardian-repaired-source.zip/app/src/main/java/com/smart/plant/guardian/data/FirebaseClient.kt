package com.smart.plant.guardian.data

import com.smart.plant.guardian.model.AuditEntry
import com.smart.plant.guardian.model.Device
import com.smart.plant.guardian.model.DeviceCommands
import com.smart.plant.guardian.model.DeviceMeta
import com.smart.plant.guardian.model.DeviceSensors
import com.smart.plant.guardian.model.DeviceSettings
import com.smart.plant.guardian.model.DeviceStatus
import com.smart.plant.guardian.model.FirebaseConfig
import com.smart.plant.guardian.model.HistoryPoint
import com.smart.plant.guardian.model.ScheduleSettings
import com.smart.plant.guardian.model.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

sealed class AuthResult {
    data class Success(val config: FirebaseConfig, val userProfile: UserProfile) : AuthResult()
    data class Error(val message: String, val isNetworkError: Boolean = false) : AuthResult()
}

class FirebaseClient(
    private val preferencesManager: PreferencesManager
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    // Dedicated client for Server-Sent Events (infinite read timeout)
    private val sseHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    /**
     * Sign In with Email & Password via Firebase Auth REST API
     */
    suspend fun signIn(config: FirebaseConfig): AuthResult = withContext(Dispatchers.IO) {
        if (!config.isConfigured) {
            return@withContext AuthResult.Error("Firebase settings are incomplete. Please provide Database URL, API Key, and App ID.")
        }
        if (config.email.isBlank() || config.password.isBlank()) {
            return@withContext AuthResult.Error("Please enter your email and password.")
        }

        val url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${config.apiKey.trim()}"
        val bodyJson = JSONObject().apply {
            put("email", config.email.trim())
            put("password", config.password)
            put("returnSecureToken", true)
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(bodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            httpClient.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = parseAuthError(responseStr, response.code)
                    return@withContext AuthResult.Error(errorMsg)
                }

                val json = JSONObject(responseStr)
                val idToken = json.getString("idToken")
                val refreshToken = json.getString("refreshToken")
                val localId = json.getString("localId")
                val expiresInSec = json.optLong("expiresIn", 3600L)
                val tokenExpiresEpochMs = System.currentTimeMillis() + (expiresInSec * 1000L)

                val updatedConfig = config.copy(
                    idToken = idToken,
                    refreshToken = refreshToken,
                    localId = localId,
                    tokenExpiresEpochMs = tokenExpiresEpochMs
                )
                preferencesManager.saveFirebaseConfig(updatedConfig)

                // Fetch or initialize profile
                val profile = fetchOrCreateUserProfile(updatedConfig, localId, config.email)
                AuthResult.Success(updatedConfig, profile)
            }
        } catch (e: IOException) {
            AuthResult.Error("No internet connection or server unreachable: ${e.localizedMessage}", isNetworkError = true)
        } catch (e: Exception) {
            AuthResult.Error("Authentication error: ${e.localizedMessage}")
        }
    }

    /**
     * Register account via Firebase Auth REST API
     */
    suspend fun register(config: FirebaseConfig): AuthResult = withContext(Dispatchers.IO) {
        if (!config.isConfigured) {
            return@withContext AuthResult.Error("Firebase settings are incomplete. Please provide Database URL, API Key, and App ID.")
        }
        if (config.email.isBlank() || config.password.isBlank()) {
            return@withContext AuthResult.Error("Please enter your email and password.")
        }

        val url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${config.apiKey.trim()}"
        val bodyJson = JSONObject().apply {
            put("email", config.email.trim())
            put("password", config.password)
            put("returnSecureToken", true)
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(bodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            httpClient.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = parseAuthError(responseStr, response.code)
                    return@withContext AuthResult.Error(errorMsg)
                }

                val json = JSONObject(responseStr)
                val idToken = json.getString("idToken")
                val refreshToken = json.getString("refreshToken")
                val localId = json.getString("localId")
                val expiresInSec = json.optLong("expiresIn", 3600L)
                val tokenExpiresEpochMs = System.currentTimeMillis() + (expiresInSec * 1000L)

                val updatedConfig = config.copy(
                    idToken = idToken,
                    refreshToken = refreshToken,
                    localId = localId,
                    tokenExpiresEpochMs = tokenExpiresEpochMs
                )
                preferencesManager.saveFirebaseConfig(updatedConfig)

                // Register screen: new accounts are viewer + pending
                val now = System.currentTimeMillis()
                val newProfile = UserProfile(
                    uid = localId,
                    email = config.email.trim(),
                    displayName = config.email.trim().substringBefore("@"),
                    role = UserProfile.ROLE_VIEWER,
                    status = UserProfile.STATUS_PENDING,
                    createdAt = now,
                    lastLoginMs = now
                )
                saveInitialUserProfile(updatedConfig, newProfile)
                AuthResult.Success(updatedConfig, newProfile)
            }
        } catch (e: IOException) {
            AuthResult.Error("No internet connection: ${e.localizedMessage}", isNetworkError = true)
        } catch (e: Exception) {
            AuthResult.Error("Registration error: ${e.localizedMessage}")
        }
    }

    /**
     * Refresh auth token if expired or about to expire
     */
    suspend fun getValidIdToken(config: FirebaseConfig): String? = withContext(Dispatchers.IO) {
        if (config.idToken.isBlank()) return@withContext null
        val now = System.currentTimeMillis()
        // If token has at least 5 minutes remaining, use it
        if (config.tokenExpiresEpochMs - now > 5 * 60 * 1000L) {
            return@withContext config.idToken
        }

        if (config.refreshToken.isBlank() || config.apiKey.isBlank()) {
            return@withContext config.idToken
        }

        val url = "https://securetoken.googleapis.com/v1/token?key=${config.apiKey.trim()}"
        val bodyStr = "grant_type=refresh_token&refresh_token=${config.refreshToken}"

        try {
            val request = Request.Builder()
                .url(url)
                .post(bodyStr.toRequestBody("application/x-www-form-urlencoded".toMediaType()))
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val json = JSONObject(response.body?.string().orEmpty())
                    val newIdToken = json.getString("id_token")
                    val newRefreshToken = json.optString("refresh_token", config.refreshToken)
                    val expiresInSec = json.optLong("expires_in", 3600L)
                    val newExpires = System.currentTimeMillis() + (expiresInSec * 1000L)

                    val updated = config.copy(
                        idToken = newIdToken,
                        refreshToken = newRefreshToken,
                        tokenExpiresEpochMs = newExpires
                    )
                    preferencesManager.saveFirebaseConfig(updated)
                    return@withContext newIdToken
                }
            }
        } catch (_: Exception) {
            // Fallback to existing token
        }
        return@withContext config.idToken
    }

    /**
     * Fetch server time offset (.info/serverTimeOffset)
     */
    suspend fun fetchServerTimeOffset(config: FirebaseConfig): Long = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext 0L
        val url = "${config.cleanDatabaseUrl}/.info/serverTimeOffset.json?auth=$token"
        try {
            val request = Request.Builder().url(url).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()?.trim().orEmpty()
                    return@withContext body.toLongOrNull() ?: 0L
                }
            }
        } catch (_: Exception) { }
        return@withContext 0L
    }

    /**
     * Fetch user profile from /users/{uid}.json
     */
    suspend fun fetchUserProfile(config: FirebaseConfig, uid: String): UserProfile? = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext null
        val url = "${config.cleanDatabaseUrl}/users/$uid.json?auth=$token"
        try {
            val request = Request.Builder().url(url).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val str = response.body?.string()?.trim().orEmpty()
                    if (str == "null" || str.isBlank()) return@withContext null
                    return@withContext parseUserProfile(uid, JSONObject(str))
                }
            }
        } catch (_: Exception) { }
        return@withContext null
    }

    private suspend fun fetchOrCreateUserProfile(config: FirebaseConfig, uid: String, email: String): UserProfile {
        val existing = fetchUserProfile(config, uid)
        val now = System.currentTimeMillis()
        if (existing != null) {
            // Update lastLoginMs
            updateUserLastLogin(config, uid, now)
            return existing.copy(lastLoginMs = now)
        }
        val newProfile = UserProfile(
            uid = uid,
            email = email,
            displayName = email.substringBefore("@"),
            role = UserProfile.ROLE_VIEWER,
            status = UserProfile.STATUS_PENDING,
            createdAt = now,
            lastLoginMs = now
        )
        saveInitialUserProfile(config, newProfile)
        return newProfile
    }

    private suspend fun saveInitialUserProfile(config: FirebaseConfig, profile: UserProfile) = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext
        val url = "${config.cleanDatabaseUrl}/users/${profile.uid}.json?auth=$token"
        val json = JSONObject().apply {
            put("email", profile.email)
            put("displayName", profile.displayName)
            put("role", profile.role)
            put("status", profile.status)
            put("createdAt", profile.createdAt)
            put("lastLoginMs", profile.lastLoginMs)
        }
        try {
            val request = Request.Builder()
                .url(url)
                .put(json.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(request).execute().close()
        } catch (_: Exception) { }
    }

    private suspend fun updateUserLastLogin(config: FirebaseConfig, uid: String, lastLoginMs: Long) = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext
        val url = "${config.cleanDatabaseUrl}/users/$uid/lastLoginMs.json?auth=$token"
        try {
            val request = Request.Builder()
                .url(url)
                .put(lastLoginMs.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(request).execute().close()
        } catch (_: Exception) { }
    }

    /**
     * Admin: Fetch all users from /users.json
     */
    suspend fun fetchAllUsers(config: FirebaseConfig): List<UserProfile> = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext emptyList()
        val url = "${config.cleanDatabaseUrl}/users.json?auth=$token"
        try {
            val request = Request.Builder().url(url).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val str = response.body?.string()?.trim().orEmpty()
                    if (str == "null" || str.isBlank()) return@withContext emptyList()
                    val json = JSONObject(str)
                    val list = mutableListOf<UserProfile>()
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val uid = keys.next()
                        val uJson = json.optJSONObject(uid) ?: continue
                        list.add(parseUserProfile(uid, uJson))
                    }
                    return@withContext list
                }
            }
        } catch (_: Exception) { }
        return@withContext emptyList()
    }

    /**
     * Admin: Update user role and status
     */
    suspend fun updateUserRoleAndStatus(
        config: FirebaseConfig,
        targetUid: String,
        role: String,
        status: String
    ): Boolean = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext false
        val url = "${config.cleanDatabaseUrl}/users/$targetUid.json?auth=$token"
        val patchJson = JSONObject().apply {
            put("role", role)
            put("status", status)
        }
        try {
            val request = Request.Builder()
                .url(url)
                .patch(patchJson.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(request).execute().use { response ->
                return@withContext response.isSuccessful
            }
        } catch (_: Exception) {
            return@withContext false
        }
    }

    /**
     * Auto-Discovery: Fetch all devices from /devices.json for admin, or /users/{uid}/devices.json for members
     */
    suspend fun fetchAllDevices(config: FirebaseConfig, userProfile: UserProfile? = null): Map<String, Device> = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext emptyMap()
        if (userProfile == null || userProfile.isAdmin || userProfile.isDeviceRole) {
            val url = "${config.cleanDatabaseUrl}/devices.json?auth=$token"
            try {
                val request = Request.Builder().url(url).get().build()
                httpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val str = response.body?.string()?.trim().orEmpty()
                        if (str != "null" && str.isNotBlank()) {
                            val json = JSONObject(str)
                            return@withContext parseDevicesMap(json)
                        }
                    }
                }
            } catch (_: Exception) { }
        }

        // For member users (operator/viewer), discover via /users/{uid}/devices.json
        val uid = userProfile?.uid ?: config.localId
        if (uid.isNotBlank()) {
            try {
                val userDevicesUrl = "${config.cleanDatabaseUrl}/users/$uid/devices.json?auth=$token"
                val request = Request.Builder().url(userDevicesUrl).get().build()
                httpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val str = response.body?.string()?.trim().orEmpty()
                        if (str != "null" && str.isNotBlank()) {
                            val json = JSONObject(str)
                            val devMap = mutableMapOf<String, Device>()
                            val keys = json.keys()
                            while (keys.hasNext()) {
                                val devId = keys.next()
                                val dev = fetchSingleDevice(config, devId)
                                if (dev != null) {
                                    devMap[devId] = dev
                                }
                            }
                            return@withContext devMap
                        }
                    }
                }
            } catch (_: Exception) { }
        }

        return@withContext emptyMap()
    }

    suspend fun fetchSingleDevice(config: FirebaseConfig, deviceId: String): Device? = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext null
        val url = "${config.cleanDatabaseUrl}/devices/$deviceId.json?auth=$token"
        try {
            val request = Request.Builder().url(url).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val str = response.body?.string()?.trim().orEmpty()
                    if (str == "null" || str.isBlank()) return@withContext null
                    val json = JSONObject(str)
                    return@withContext parseDevice(deviceId, json)
                }
            }
        } catch (_: Exception) { }
        return@withContext null
    }

    /**
     * Fetch the last 200 history entries for a device
     */
    suspend fun fetchDeviceHistory(config: FirebaseConfig, deviceId: String): List<HistoryPoint> = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext emptyList()
        val url = "${config.cleanDatabaseUrl}/devices/$deviceId/history.json?auth=$token&orderBy=\"\$key\"&limitToLast=200"
        try {
            val request = Request.Builder().url(url).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val str = response.body?.string()?.trim().orEmpty()
                    if (str == "null" || str.isBlank()) return@withContext emptyList()
                    val json = JSONObject(str)
                    val points = mutableListOf<HistoryPoint>()
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val pushId = keys.next()
                        val item = json.optJSONObject(pushId) ?: continue
                        points.add(parseHistoryPoint(pushId, item))
                    }
                    return@withContext points.sortedBy { it.timestampMs }
                }
            }
        } catch (_: Exception) { }
        return@withContext emptyList()
    }

    /**
     * Send command to /devices/{deviceId}/commands.json
     */
    suspend fun sendCommand(
        config: FirebaseConfig,
        deviceId: String,
        commandKey: String,
        commandValue: Any
    ): Boolean = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext false
        val url = "${config.cleanDatabaseUrl}/devices/$deviceId/commands.json?auth=$token"
        val patch = JSONObject().apply {
            put(commandKey, commandValue)
        }
        try {
            val request = Request.Builder()
                .url(url)
                .patch(patch.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(request).execute().use { response ->
                return@withContext response.isSuccessful
            }
        } catch (_: Exception) {
            return@withContext false
        }
    }

    /**
     * Update settings at /devices/{deviceId}/settings.json
     */
    suspend fun updateDeviceSettings(
        config: FirebaseConfig,
        deviceId: String,
        settings: DeviceSettings
    ): Boolean = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext false
        val url = "${config.cleanDatabaseUrl}/devices/$deviceId/settings.json?auth=$token"
        val json = serializeDeviceSettings(settings)
        try {
            val request = Request.Builder()
                .url(url)
                .put(json.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(request).execute().use { response ->
                return@withContext response.isSuccessful
            }
        } catch (_: Exception) {
            return@withContext false
        }
    }

    /**
     * Assign / remove device member: /devices/{deviceId}/members/{uid}.json
     * Also writes /users/{memberUid}/devices/{deviceId}.json for member-level discovery.
     */
    suspend fun setDeviceMember(
        config: FirebaseConfig,
        deviceId: String,
        memberUid: String,
        assigned: Boolean
    ): Boolean = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext false
        val urlDevice = "${config.cleanDatabaseUrl}/devices/$deviceId/members/$memberUid.json?auth=$token"
        val urlUser = "${config.cleanDatabaseUrl}/users/$memberUid/devices/$deviceId.json?auth=$token"
        try {
            val reqDevice = if (assigned) {
                Request.Builder().url(urlDevice).put("true".toRequestBody(jsonMediaType)).build()
            } else {
                Request.Builder().url(urlDevice).delete().build()
            }
            val reqUser = if (assigned) {
                Request.Builder().url(urlUser).put("true".toRequestBody(jsonMediaType)).build()
            } else {
                Request.Builder().url(urlUser).delete().build()
            }
            val res1 = httpClient.newCall(reqDevice).execute().use { it.isSuccessful }
            val res2 = httpClient.newCall(reqUser).execute().use { it.isSuccessful }
            return@withContext res1 && res2
        } catch (_: Exception) {
            return@withContext false
        }
    }

    /**
     * Write an audit entry at /audit.json
     */
    suspend fun writeAudit(config: FirebaseConfig, audit: AuditEntry): Boolean = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext false
        val url = "${config.cleanDatabaseUrl}/audit.json?auth=$token"
        val json = JSONObject().apply {
            put("uid", audit.uid)
            put("email", audit.email)
            put("action", audit.action)
            put("deviceId", audit.deviceId)
            put("timestampMs", if (audit.timestampMs > 0) audit.timestampMs else System.currentTimeMillis())
            put("details", audit.details)
        }
        try {
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(request).execute().use { response ->
                return@withContext response.isSuccessful
            }
        } catch (_: Exception) {
            return@withContext false
        }
    }

    /**
     * Fetch audit log from /audit.json
     */
    suspend fun fetchAuditLog(config: FirebaseConfig): List<AuditEntry> = withContext(Dispatchers.IO) {
        val token = getValidIdToken(config) ?: return@withContext emptyList()
        val url = "${config.cleanDatabaseUrl}/audit.json?auth=$token&orderBy=\"timestampMs\"&limitToLast=100"
        try {
            val request = Request.Builder().url(url).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val str = response.body?.string()?.trim().orEmpty()
                    if (str == "null" || str.isBlank()) return@withContext emptyList()
                    val json = JSONObject(str)
                    val list = mutableListOf<AuditEntry>()
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val pushId = keys.next()
                        val item = json.optJSONObject(pushId) ?: continue
                        list.add(
                            AuditEntry(
                                id = pushId,
                                uid = item.optString("uid", ""),
                                email = item.optString("email", ""),
                                action = item.optString("action", ""),
                                deviceId = item.optString("deviceId", ""),
                                timestampMs = item.optLong("timestampMs", 0L),
                                details = item.optString("details", "")
                            )
                        )
                    }
                    return@withContext list.sortedByDescending { it.timestampMs }
                }
            }
        } catch (_: Exception) { }
        return@withContext emptyList()
    }

    /**
     * Real-time Server-Sent Events (SSE) Stream on /devices.json for admin/device,
     * or member-level device polling for assigned devices.
     */
    fun streamDevices(config: FirebaseConfig, userProfile: UserProfile? = null): Flow<Map<String, Device>> = flow {
        val token = getValidIdToken(config) ?: return@flow
        val isAdminOrDevice = userProfile == null || userProfile.isAdmin || userProfile.isDeviceRole

        if (!isAdminOrDevice) {
            // For member users, fetch their assigned devices and emit
            val initial = fetchAllDevices(config, userProfile)
            emit(initial)
            while (true) {
                kotlinx.coroutines.delay(10_000L)
                val refreshed = fetchAllDevices(config, userProfile)
                emit(refreshed)
            }
        }

        val url = "${config.cleanDatabaseUrl}/devices.json?auth=$token"
        val request = Request.Builder()
            .url(url)
            .addHeader("Accept", "text/event-stream")
            .build()

        var response: Response? = null
        try {
            response = sseHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                // If SSE fails or unauthorized, emit initial one-time fetch
                val fallback = fetchAllDevices(config, userProfile)
                emit(fallback)
                return@flow
            }

            val reader = BufferedReader(InputStreamReader(response.body!!.byteStream()))
            var currentEvent = ""
            var currentDevices = mutableMapOf<String, Device>()

            while (true) {
                val line = reader.readLine() ?: break
                if (line.startsWith("event:")) {
                    currentEvent = line.substring(6).trim()
                } else if (line.startsWith("data:")) {
                    val dataStr = line.substring(5).trim()
                    if (dataStr.isNotBlank() && dataStr != "null") {
                        try {
                            val dataJson = JSONObject(dataStr)
                            val path = dataJson.optString("path", "/")
                            val dataObj = dataJson.opt("data")

                            if (path == "/" || path.isEmpty()) {
                                if (dataObj is JSONObject) {
                                    currentDevices = parseDevicesMap(dataObj).toMutableMap()
                                    emit(currentDevices.toMap())
                                }
                            } else {
                                // Nested patch/put on /devices, e.g. /ESP32_01/sensors
                                val parts = path.trim('/').split('/')
                                if (parts.isNotEmpty()) {
                                    val devId = parts[0]
                                    // Refresh specific device or all
                                    val refreshed = fetchAllDevices(config)
                                    currentDevices = refreshed.toMutableMap()
                                    emit(currentDevices.toMap())
                                }
                            }
                        } catch (_: Exception) {
                            // Keep alive or unparsable line
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Stream ended or connection lost, fallback to single fetch
            val fallback = fetchAllDevices(config)
            emit(fallback)
        } finally {
            response?.close()
        }
    }.flowOn(Dispatchers.IO)

    // Helpers
    private fun parseAuthError(responseStr: String, httpCode: Int): String {
        return try {
            val json = JSONObject(responseStr)
            val error = json.optJSONObject("error")
            val message = error?.optString("message", "") ?: ""
            when {
                message.contains("EMAIL_NOT_FOUND") || message.contains("INVALID_LOGIN_CREDENTIALS") ->
                    "Account not found or password incorrect."
                message.contains("INVALID_PASSWORD") -> "Wrong password. Please try again."
                message.contains("USER_DISABLED") -> "This account has been disabled."
                message.contains("EMAIL_EXISTS") -> "An account with this email already exists."
                message.contains("WEAK_PASSWORD") -> "Password should be at least 6 characters."
                message.contains("API_KEY_INVALID") -> "Invalid Firebase Web API Key."
                message.contains("TOO_MANY_ATTEMPTS_TRY_LATER") -> "Too many attempts. Please try again later."
                httpCode == 403 -> "Permission denied (HTTP 403). Check Firebase rules and API key."
                httpCode == 401 -> "Unauthorized. Please verify Firebase credentials."
                message.isNotBlank() -> message.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() }
                else -> "Authentication failed (code $httpCode)."
            }
        } catch (_: Exception) {
            "Authentication failed (code $httpCode)."
        }
    }

    private fun parseUserProfile(uid: String, json: JSONObject): UserProfile {
        return UserProfile(
            uid = uid,
            email = json.optString("email", ""),
            displayName = json.optString("displayName", ""),
            role = json.optString("role", UserProfile.ROLE_VIEWER),
            status = json.optString("status", UserProfile.STATUS_PENDING),
            createdAt = json.optLong("createdAt", 0L),
            lastLoginMs = json.optLong("lastLoginMs", 0L)
        )
    }

    private fun parseDevicesMap(json: JSONObject): Map<String, Device> {
        val result = mutableMapOf<String, Device>()
        val keys = json.keys()
        while (keys.hasNext()) {
            val devId = keys.next()
            val dJson = json.optJSONObject(devId) ?: continue
            result[devId] = parseDevice(devId, dJson)
        }
        return result
    }

    private fun parseDevice(devId: String, json: JSONObject): Device {
        val meta = json.optJSONObject("meta")?.let {
            DeviceMeta(
                name = it.optString("name", null),
                locationName = it.optString("locationName", null),
                latitude = if (it.has("latitude")) it.optDouble("latitude") else null,
                longitude = if (it.has("longitude")) it.optDouble("longitude") else null,
                firmwareVersion = it.optString("firmwareVersion", null),
                wifiSsid = it.optString("wifiSsid", null),
                ipAddress = it.optString("ipAddress", null)
            )
        }

        val sensors = json.optJSONObject("sensors")?.let {
            DeviceSensors(
                temperatureC = if (it.has("temperatureC")) it.optDouble("temperatureC").toFloat() else null,
                humidityPercent = if (it.has("humidityPercent")) it.optDouble("humidityPercent").toFloat() else null,
                soilZone1 = if (it.has("soilZone1")) it.optInt("soilZone1") else null,
                soilZone2 = if (it.has("soilZone2")) it.optInt("soilZone2") else null,
                soilZone3 = if (it.has("soilZone3")) it.optInt("soilZone3") else null,
                lightPercent = if (it.has("lightPercent")) it.optInt("lightPercent") else null,
                isRaining = if (it.has("isRaining")) it.optBoolean("isRaining") else null,
                batteryPercent = if (it.has("batteryPercent")) it.optInt("batteryPercent") else null,
                solarCharging = if (it.has("solarCharging")) it.optBoolean("solarCharging") else null,
                lastSeenEpochMs = if (it.has("lastSeenEpochMs")) it.optLong("lastSeenEpochMs") else null
            )
        }

        val status = json.optJSONObject("status")?.let {
            DeviceStatus(
                pumpOn = if (it.has("pumpOn")) it.optBoolean("pumpOn") else null,
                mode = it.optString("mode", null),
                activeRunSeconds = if (it.has("activeRunSeconds")) it.optInt("activeRunSeconds") else null
            )
        }

        val commands = json.optJSONObject("commands")?.let {
            DeviceCommands(
                power = if (it.has("power")) it.optBoolean("power") else null,
                pump = if (it.has("pump")) it.optBoolean("pump") else null,
                mode = it.optString("mode", null),
                buzzer = if (it.has("buzzer")) it.optBoolean("buzzer") else null,
                speaker = if (it.has("speaker")) it.optBoolean("speaker") else null,
                ledRed = if (it.has("ledRed")) it.optBoolean("ledRed") else null,
                ledBlue = if (it.has("ledBlue")) it.optBoolean("ledBlue") else null,
                ledGreen = if (it.has("ledGreen")) it.optBoolean("ledGreen") else null,
                ledYellow = if (it.has("ledYellow")) it.optBoolean("ledYellow") else null
            )
        }

        val settings = json.optJSONObject("settings")?.let {
            parseDeviceSettings(it)
        } ?: DeviceSettings()

        val members = mutableMapOf<String, Boolean>()
        json.optJSONObject("members")?.let { mJson ->
            val mKeys = mJson.keys()
            while (mKeys.hasNext()) {
                val uid = mKeys.next()
                members[uid] = mJson.optBoolean(uid, true)
            }
        }

        val historyPoints = mutableListOf<HistoryPoint>()
        json.optJSONObject("history")?.let { hJson ->
            val hKeys = hJson.keys()
            while (hKeys.hasNext()) {
                val pushId = hKeys.next()
                val item = hJson.optJSONObject(pushId) ?: continue
                historyPoints.add(parseHistoryPoint(pushId, item))
            }
        }

        return Device(
            id = devId,
            meta = meta,
            sensors = sensors,
            status = status,
            commands = commands,
            settings = settings,
            members = members,
            history = historyPoints.sortedBy { it.timestampMs }
        )
    }

    private fun parseDeviceSettings(json: JSONObject): DeviceSettings {
        val schedJson = json.optJSONObject("schedule")
        val activeDaysList = mutableListOf<Int>()
        schedJson?.optJSONArray("activeDays")?.let { arr ->
            for (i in 0 until arr.length()) {
                activeDaysList.add(arr.optInt(i))
            }
        }

        val schedule = ScheduleSettings(
            enabled = schedJson?.optBoolean("enabled", false) ?: false,
            startHour = schedJson?.optInt("startHour", 6) ?: 6,
            startMinute = schedJson?.optInt("startMinute", 0) ?: 0,
            durationMinutes = schedJson?.optInt("durationMinutes", 10) ?: 10,
            activeDays = if (activeDaysList.isNotEmpty()) activeDaysList else listOf(1, 2, 3, 4, 5, 6, 7)
        )

        return DeviceSettings(
            soilDryPercent = json.optInt("soilDryPercent", 30),
            soilTargetPercent = json.optInt("soilTargetPercent", 65),
            highTempAlertThresholdC = if (json.has("highTempAlertThresholdC")) json.optDouble("highTempAlertThresholdC").toFloat() else 35.0f,
            lowBatteryAlertPercent = json.optInt("lowBatteryAlertPercent", 20),
            maxPumpRunTimeMinutes = json.optInt("maxPumpRunTimeMinutes", 15),
            schedule = schedule
        )
    }

    private fun serializeDeviceSettings(settings: DeviceSettings): JSONObject {
        return JSONObject().apply {
            put("soilDryPercent", settings.soilDryPercent)
            put("soilTargetPercent", settings.soilTargetPercent)
            put("highTempAlertThresholdC", settings.highTempAlertThresholdC)
            put("lowBatteryAlertPercent", settings.lowBatteryAlertPercent)
            put("maxPumpRunTimeMinutes", settings.maxPumpRunTimeMinutes)
            put("schedule", JSONObject().apply {
                put("enabled", settings.schedule.enabled)
                put("startHour", settings.schedule.startHour)
                put("startMinute", settings.schedule.startMinute)
                put("durationMinutes", settings.schedule.durationMinutes)
                put("activeDays", JSONArray(settings.schedule.activeDays))
            })
        }
    }

    private fun parseHistoryPoint(pushId: String, json: JSONObject): HistoryPoint {
        return HistoryPoint(
            pushId = pushId,
            timestampMs = json.optLong("timestampMs", 0L),
            tempC = if (json.has("tempC")) json.optDouble("tempC").toFloat() else null,
            humidity = if (json.has("humidity")) json.optDouble("humidity").toFloat() else null,
            soilAvg = if (json.has("soilAvg")) json.optDouble("soilAvg").toFloat() else null,
            zone1 = if (json.has("zone1")) json.optInt("zone1") else null,
            zone2 = if (json.has("zone2")) json.optInt("zone2") else null,
            zone3 = if (json.has("zone3")) json.optInt("zone3") else null,
            lightPercent = if (json.has("lightPercent")) json.optInt("lightPercent") else null,
            batteryPercent = if (json.has("batteryPercent")) json.optInt("batteryPercent") else null
        )
    }
}
