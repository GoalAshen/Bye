package com.smart.plant.guardian.model

data class FirebaseConfig(
    val databaseUrl: String = "",
    val apiKey: String = "",
    val projectId: String = "",
    val appId: String = "",
    val email: String = "",
    val password: String = "",
    val idToken: String = "",
    val refreshToken: String = "",
    val localId: String = "",
    val tokenExpiresEpochMs: Long = 0L
) {
    val isConfigured: Boolean
        get() = databaseUrl.trim().isNotBlank() &&
                apiKey.trim().isNotBlank() &&
                appId.trim().isNotBlank()

    val isAuthenticated: Boolean
        get() = isConfigured && idToken.isNotBlank() && localId.isNotBlank()

    val cleanDatabaseUrl: String
        get() {
            var url = databaseUrl.trim()
            if (url.endsWith("/")) {
                url = url.substring(0, url.length - 1)
            }
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://$url"
            }
            return url
        }

    companion object {
        // Built in from google-services.json (project smart-plant-guardian-nevidu),
        // so the user never has to type any technical Firebase data.
        const val BUILT_IN_DATABASE_URL =
            "https://smart-plant-guardian-nevidu-default-rtdb.asia-southeast1.firebasedatabase.app"
        const val BUILT_IN_API_KEY = "AIzaSyAiYqM2H8p7RjkvcCKGebRpKP8aPjhEdGA"
        const val BUILT_IN_PROJECT_ID = "smart-plant-guardian-nevidu"
        const val BUILT_IN_APP_ID = "1:548760724711:android:8934d194ac7baa24cdee42"
    }
}
