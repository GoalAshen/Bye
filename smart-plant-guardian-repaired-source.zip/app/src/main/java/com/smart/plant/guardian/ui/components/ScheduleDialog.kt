package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smart.plant.guardian.model.ScheduleSettings
import kotlin.math.roundToInt

@Composable
fun ScheduleDialog(
    initialSchedule: ScheduleSettings,
    isOperatorOrAdmin: Boolean,
    onDismiss: () -> Unit,
    onSaveSchedule: (ScheduleSettings) -> Unit
) {
    var enabled by remember { mutableStateOf(initialSchedule.enabled) }
    var startHour by remember { mutableIntStateOf(initialSchedule.startHour) }
    var startMinute by remember { mutableIntStateOf(initialSchedule.startMinute) }
    var durationMinutes by remember { mutableIntStateOf(initialSchedule.durationMinutes) }
    var activeDays by remember { mutableStateOf(initialSchedule.activeDays.toSet()) }

    val daysOfWeek = listOf(
        1 to "Mon",
        2 to "Tue",
        3 to "Wed",
        4 to "Thu",
        5 to "Fri",
        6 to "Sat",
        7 to "Sun"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Irrigation Schedule",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Enabled Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Enable Automated Schedule",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Switch(
                        checked = enabled,
                        onCheckedChange = { if (isOperatorOrAdmin) enabled = it },
                        enabled = isOperatorOrAdmin
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Start Time
                Text(
                    text = "Start Time: ${String.format("%02d:%02d", startHour, startMinute)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Hour: $startHour", style = MaterialTheme.typography.labelSmall)
                        Slider(
                            value = startHour.toFloat(),
                            onValueChange = { startHour = it.roundToInt() },
                            valueRange = 0f..23f,
                            steps = 23,
                            enabled = isOperatorOrAdmin && enabled
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Min: $startMinute", style = MaterialTheme.typography.labelSmall)
                        Slider(
                            value = startMinute.toFloat(),
                            onValueChange = { startMinute = (it.roundToInt() / 5) * 5 },
                            valueRange = 0f..55f,
                            steps = 11,
                            enabled = isOperatorOrAdmin && enabled
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Duration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Duration:", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "$durationMinutes minutes",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Slider(
                    value = durationMinutes.toFloat(),
                    onValueChange = { durationMinutes = it.roundToInt() },
                    valueRange = 1f..60f,
                    steps = 59,
                    enabled = isOperatorOrAdmin && enabled
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Active Days
                Text(
                    text = "Active Days",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    daysOfWeek.forEach { (dayInt, label) ->
                        val isSelected = activeDays.contains(dayInt)
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                if (isOperatorOrAdmin && enabled) {
                                    activeDays = if (isSelected) {
                                        if (activeDays.size > 1) activeDays - dayInt else activeDays
                                    } else {
                                        activeDays + dayInt
                                    }
                                }
                            },
                            enabled = isOperatorOrAdmin && enabled,
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.padding(horizontal = 1.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (isOperatorOrAdmin) {
                Button(
                    onClick = {
                        val result = ScheduleSettings(
                            enabled = enabled,
                            startHour = startHour,
                            startMinute = startMinute,
                            durationMinutes = durationMinutes,
                            activeDays = activeDays.sorted()
                        )
                        onSaveSchedule(result)
                        onDismiss()
                    },
                    modifier = Modifier.testTag("save_schedule_button")
                ) {
                    Text("Save Schedule")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
