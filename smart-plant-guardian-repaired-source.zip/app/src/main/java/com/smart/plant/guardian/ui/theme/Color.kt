package com.smart.plant.guardian.ui.theme

import androidx.compose.ui.graphics.Color

// Fixed Green / Aqua Material 3 Palette (Plant Guardian signature theme)
val GreenPrimaryLight = Color(0xFF146C4E)
val GreenOnPrimaryLight = Color(0xFFFFFFFF)
val GreenPrimaryContainerLight = Color(0xFFA6F2CE)
val GreenOnPrimaryContainerLight = Color(0xFF002115)

val AquaSecondaryLight = Color(0xFF286A75)
val AquaOnSecondaryLight = Color(0xFFFFFFFF)
val AquaSecondaryContainerLight = Color(0xFFAFEBF7)
val AquaOnSecondaryContainerLight = Color(0xFF001F25)

val TerraTertiaryLight = Color(0xFF8B5000)
val TerraOnTertiaryLight = Color(0xFFFFFFFF)
val TerraTertiaryContainerLight = Color(0xFFFFDCBE)
val TerraOnTertiaryContainerLight = Color(0xFF2C1600)

val GreenBackgroundLight = Color(0xFFF6FBF6)
val GreenOnBackgroundLight = Color(0xFF181D1A)
val GreenSurfaceLight = Color(0xFFF6FBF6)
val GreenOnSurfaceLight = Color(0xFF181D1A)
val GreenSurfaceVariantLight = Color(0xFFDBE5DE)
val GreenOnSurfaceVariantLight = Color(0xFF404944)
val GreenOutlineLight = Color(0xFF707974)

val GreenPrimaryDark = Color(0xFF8AD5B3)
val GreenOnPrimaryDark = Color(0xFF003826)
val GreenPrimaryContainerDark = Color(0xFF005139)
val GreenOnPrimaryContainerDark = Color(0xFFA6F2CE)

val AquaSecondaryDark = Color(0xFF93D0DC)
val AquaOnSecondaryDark = Color(0xFF00363E)
val AquaSecondaryContainerDark = Color(0xFF064F59)
val AquaOnSecondaryContainerContainerDark = Color(0xFFAFEBF7)

val TerraTertiaryDark = Color(0xFFFFB77C)
val TerraOnTertiaryDark = Color(0xFF4A2800)
val TerraTertiaryContainerDark = Color(0xFF6A3B00)
val TerraOnTertiaryContainerDark = Color(0xFFFFDCBE)

val GreenBackgroundDark = Color(0xFF0F1512)
val GreenOnBackgroundDark = Color(0xFFDEE4DF)
val GreenSurfaceDark = Color(0xFF0F1512)
val GreenOnSurfaceDark = Color(0xFFDEE4DF)
val GreenSurfaceVariantDark = Color(0xFF404944)
val GreenOnSurfaceVariantDark = Color(0xFFBFC9C2)
val GreenOutlineDark = Color(0xFF8A938D)
