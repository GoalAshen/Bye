package com.smart.plant.guardian.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.smart.plant.guardian.model.Device
import com.smart.plant.guardian.model.DeviceSettings
import com.smart.plant.guardian.model.ThemeMode
import com.smart.plant.guardian.model.UserProfile
import com.smart.plant.guardian.ui.components.DeviceMapCard
import com.smart.plant.guardian.ui.components.HeroTempHumidityCard
import com.smart.plant.guardian.ui.components.HistoryChartCard
import com.smart.plant.guardian.ui.components.OnlineOfflineBadge
import com.smart.plant.guardian.ui.components.RelayControlsCard
import com.smart.plant.guardian.ui.components.ScheduleDialog
import com.smart.plant.guardian.ui.components.SoilGaugesRow
import com.smart.plant.guardian.ui.components.TelemetryQuickGrid
import com.smart.plant.guardian.ui.components.ThresholdSlidersCard
import com.smart.plant.guardian.ui.components.TopBarLogo
import com.smart.plant.guardian.viewmodel.UiMessage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    userProfile: UserProfile,
    devices: Map<String, Device>,
    selectedDeviceId: String?,
    nowServerEpochMs: Long,
    pendingCommandKey: String?,
    uiMessage: UiMessage?,
    currentThemeMode: ThemeMode,
    onSelectDevice: (String) -> Unit,
    onSendCommand: (deviceId: String, key: String, value: Any) -> Unit,
    onSaveSettings: (deviceId: String, DeviceSettings) -> Unit,
    onOpenAdminPanel: () -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onRefreshDevices: () -> Unit,
    onSignOut: () -> Unit,
    onClearUiMessage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val snackbarHostState = remember { SnackbarHostState() }
    var showThemeMenu by remember { mutableStateOf(false) }
    var showDeviceSwitcherMenu by remember { mutableStateOf(false) }
    var showScheduleDialog by remember { mutableStateOf(false) }

    val activeDevice = selectedDeviceId?.let { devices[it] } ?: devices.values.firstOrNull()

    // Show Snackbars for UI feedback / "Device did not respond"
    LaunchedEffect(uiMessage) {
        uiMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg.text)
            onClearUiMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { TopBarLogo() },
                actions = {
                    // Refresh
                    IconButton(
                        onClick = onRefreshDevices,
                        modifier = Modifier.testTag("refresh_devices_action")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }

                    // Theme selector menu
                    Box {
                        IconButton(
                            onClick = { showThemeMenu = true },
                            modifier = Modifier.testTag("theme_selector_action")
                        ) {
                            Icon(Icons.Default.ColorLens, contentDescription = "Theme")
                        }
                        DropdownMenu(
                            expanded = showThemeMenu,
                            onDismissRequest = { showThemeMenu = false }
                        ) {
                            ThemeMode.entries.forEach { mode ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = mode.label,
                                            fontWeight = if (currentThemeMode == mode) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        onSetThemeMode(mode)
                                        showThemeMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Admin Shield Icon: Only visible to Admins
                    if (userProfile.isAdmin) {
                        IconButton(
                            onClick = onOpenAdminPanel,
                            modifier = Modifier.testTag("admin_panel_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Admin Panel",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Sign Out
                    IconButton(
                        onClick = onSignOut,
                        modifier = Modifier.testTag("sign_out_action")
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = "Sign Out")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier
    ) { innerPadding ->
        if (devices.isEmpty()) {
            // Requirement 3b: Empty state with no devices
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("no_devices_empty_state_card"),
                    shape = MaterialTheme.shapes.extraLarge,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Devices,
                            contentDescription = "Waiting for device",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Auto-Discovery Active",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Waiting for your ESP32 to register. Power it on and connect it to WiFi.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        OutlinedButton(
                            onClick = onRefreshDevices,
                            modifier = Modifier.testTag("manual_refresh_empty_state_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Refresh Now")
                        }
                    }
                }
            }
        } else if (activeDevice != null) {
            val isOnline = activeDevice.isOnline(nowServerEpochMs)
            val sensors = activeDevice.sensors
            val settings = activeDevice.settings
            val isOperatorOrAdmin = userProfile.isOperator

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    // Device Switcher Bar
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("device_switcher_surface"),
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        tonalElevation = 1.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDeviceSwitcherMenu = true }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(
                                            if (isOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                            CircleShape
                                        )
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = activeDevice.displayName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "ID: ${activeDevice.id} • ${activeDevice.meta?.locationName ?: "Field"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OnlineOfflineBadge(
                                    isOnline = isOnline,
                                    lastSeenEpochMs = sensors?.lastSeenEpochMs,
                                    nowServerEpochMs = nowServerEpochMs
                                )
                                if (devices.size > 1) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Switch Device",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        // Switcher Dropdown
                        if (devices.size > 1) {
                            DropdownMenu(
                                expanded = showDeviceSwitcherMenu,
                                onDismissRequest = { showDeviceSwitcherMenu = false }
                            ) {
                                devices.values.forEach { dev ->
                                    val devOnline = dev.isOnline(nowServerEpochMs)
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(8.dp)
                                                        .background(
                                                            if (devOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                                            CircleShape
                                                        )
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(dev.displayName)
                                            }
                                        },
                                        onClick = {
                                            onSelectDevice(dev.id)
                                            showDeviceSwitcherMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // 1. Hero Temperature and Humidity Card
                item {
                    HeroTempHumidityCard(
                        tempC = sensors?.temperatureC,
                        humidityPercent = sensors?.humidityPercent
                    )
                }

                // 2. Three Soil Moisture Gauges (Red = dry, Green = good, Blue = wet)
                item {
                    SoilGaugesRow(
                        zone1 = sensors?.soilZone1,
                        zone2 = sensors?.soilZone2,
                        zone3 = sensors?.soilZone3,
                        dryThreshold = settings.soilDryPercent,
                        targetThreshold = settings.soilTargetPercent
                    )
                }

                // 3. Quick Telemetry Grid: Light (Dark/Dim/Bright), Rain, Battery % (0-100 only, solar charging optional)
                item {
                    TelemetryQuickGrid(device = activeDevice)
                }

                // 4. Relay Status with large ON/OFF toggle, AUTO/MANUAL switch, Buzzer & Speaker test, LED groups
                item {
                    RelayControlsCard(
                        deviceStatus = activeDevice.status,
                        deviceCommands = activeDevice.commands,
                        isOperatorOrAdmin = isOperatorOrAdmin,
                        pendingCommandKey = pendingCommandKey,
                        onSendCommand = { key, value ->
                            onSendCommand(activeDevice.id, key, value)
                        }
                    )
                }

                // 5. Threshold Sliders (soilDry, soilTarget, highTemp, lowBattery, maxPumpRunTime)
                item {
                    ThresholdSlidersCard(
                        currentSettings = settings,
                        isOperatorOrAdmin = isOperatorOrAdmin,
                        onSaveSettings = { updatedSettings ->
                            onSaveSettings(activeDevice.id, updatedSettings)
                        },
                        onOpenScheduleDialog = {
                            showScheduleDialog = true
                        }
                    )
                }

                // 6. History Chart (1h, 24h, 7d)
                item {
                    HistoryChartCard(
                        history = activeDevice.history,
                        nowServerMs = nowServerEpochMs
                    )
                }

                // 7. Device Map & Metadata (Location, Coordinates, Firmware, WiFi, IP)
                item {
                    DeviceMapCard(
                        meta = activeDevice.meta,
                        deviceId = activeDevice.id
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }

            // Schedule Editor Dialog
            if (showScheduleDialog) {
                ScheduleDialog(
                    initialSchedule = settings.schedule,
                    isOperatorOrAdmin = isOperatorOrAdmin,
                    onDismiss = { showScheduleDialog = false },
                    onSaveSchedule = { updatedSchedule ->
                        onSaveSettings(activeDevice.id, settings.copy(schedule = updatedSchedule))
                    }
                )
            }
        }
    }
}
