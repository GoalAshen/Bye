package com.smart.plant.guardian.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.smart.plant.guardian.MainActivity
import com.smart.plant.guardian.R

class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "smart_plant_guardian_alerts"
        const val NOTIFICATION_ID_BASE = 1000

        // Debounce map: alertKey -> lastSentTimestampMs
        private val lastSentAlerts = mutableMapOf<String, Long>()
        private const val DEBOUNCE_INTERVAL_MS = 5 * 60 * 1000L // 5 minutes
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = context.getString(R.string.channel_alerts_name)
            val descriptionText = context.getString(R.string.channel_alerts_desc)
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
            }
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.createNotificationChannel(channel)
        }
    }

    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun sendAlert(
        deviceId: String,
        alertType: String,
        title: String,
        message: String,
        notificationSubId: Int
    ) {
        if (!hasNotificationPermission()) return

        val alertKey = "${deviceId}_${alertType}"
        val now = System.currentTimeMillis()
        val lastSent = lastSentAlerts[alertKey] ?: 0L
        if (now - lastSent < DEBOUNCE_INTERVAL_MS) {
            // Debounce active
            return
        }
        lastSentAlerts[alertKey] = now

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationSubId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        try {
            NotificationManagerCompat.from(context).notify(
                NOTIFICATION_ID_BASE + notificationSubId,
                builder.build()
            )
        } catch (_: SecurityException) {
            // Permission denied at runtime
        }
    }
}
