package com.smart.plant.guardian

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smart.plant.guardian.ui.screens.AdminPanelScreen
import com.smart.plant.guardian.ui.screens.ApprovalPendingScreen
import com.smart.plant.guardian.ui.screens.DashboardScreen
import com.smart.plant.guardian.ui.screens.SignInGateScreen
import com.smart.plant.guardian.ui.theme.SmartPlantGuardianTheme
import com.smart.plant.guardian.viewmodel.PlantGuardianViewModel

enum class ScreenState {
    SIGN_IN_GATE,
    APPROVAL_PENDING,
    DASHBOARD,
    ADMIN_PANEL
}

class MainActivity : ComponentActivity() {

    private val viewModel: PlantGuardianViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

            SmartPlantGuardianTheme(themeMode = themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    PlantGuardianApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun PlantGuardianApp(viewModel: PlantGuardianViewModel) {
    val config by viewModel.config.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val isAuthLoading by viewModel.isAuthLoading.collectAsStateWithLifecycle()
    val authError by viewModel.authError.collectAsStateWithLifecycle()

    val devices by viewModel.devices.collectAsStateWithLifecycle()
    val selectedDeviceId by viewModel.selectedDeviceId.collectAsStateWithLifecycle()
    val currentServerTimeMs by viewModel.currentServerTimeMs.collectAsStateWithLifecycle()
    val pendingCommandKey by viewModel.pendingCommandKey.collectAsStateWithLifecycle()
    val uiMessage by viewModel.uiMessage.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val isAdminLoading by viewModel.isAdminLoading.collectAsStateWithLifecycle()

    var showAdminPanel by remember { mutableStateOf(false) }

    // Request notification permission on Android 13+ (API 33+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val currentScreen = when {
        userProfile == null || !config.isAuthenticated -> ScreenState.SIGN_IN_GATE
        userProfile?.isActive != true -> ScreenState.APPROVAL_PENDING
        showAdminPanel && userProfile?.isAdmin == true -> ScreenState.ADMIN_PANEL
        else -> ScreenState.DASHBOARD
    }

    when (currentScreen) {
        ScreenState.SIGN_IN_GATE -> {
            SignInGateScreen(
                currentConfig = config,
                authError = authError,
                isLoading = isAuthLoading,
                onSaveConfigAndSignIn = { updatedConfig, isRegister ->
                    if (isRegister) {
                        viewModel.register(updatedConfig)
                    } else {
                        viewModel.signIn(updatedConfig)
                    }
                },
                onClearError = { viewModel.clearAuthError() }
            )
        }

        ScreenState.APPROVAL_PENDING -> {
            userProfile?.let { profile ->
                ApprovalPendingScreen(
                    profile = profile,
                    isLoading = isAuthLoading,
                    onCheckStatus = { viewModel.checkUserStatus() },
                    onSignOut = { viewModel.signOut() }
                )
            }
        }

        ScreenState.DASHBOARD -> {
            userProfile?.let { profile ->
                DashboardScreen(
                    userProfile = profile,
                    devices = devices,
                    selectedDeviceId = selectedDeviceId,
                    nowServerEpochMs = currentServerTimeMs,
                    pendingCommandKey = pendingCommandKey,
                    uiMessage = uiMessage,
                    currentThemeMode = themeMode,
                    onSelectDevice = { viewModel.selectDevice(it) },
                    onSendCommand = { devId, key, value ->
                        viewModel.sendDeviceCommand(devId, key, value)
                    },
                    onSaveSettings = { devId, settings ->
                        viewModel.updateSettings(devId, settings)
                    },
                    onOpenAdminPanel = {
                        showAdminPanel = true
                        viewModel.loadAdminData()
                    },
                    onSetThemeMode = { viewModel.setThemeMode(it) },
                    onRefreshDevices = { viewModel.refreshDevicesManually() },
                    onSignOut = { viewModel.signOut() },
                    onClearUiMessage = { viewModel.clearUiMessage() }
                )
            }
        }

        ScreenState.ADMIN_PANEL -> {
            BackHandler {
                showAdminPanel = false
            }

            AdminPanelScreen(
                users = allUsers,
                devices = devices,
                auditLogs = auditLogs,
                isLoading = isAdminLoading,
                nowServerEpochMs = currentServerTimeMs,
                onBack = { showAdminPanel = false },
                onRefreshAdminData = { viewModel.loadAdminData() },
                onUpdateUser = { uid, role, status ->
                    viewModel.adminUpdateUser(uid, role, status)
                },
                onSetDeviceMember = { devId, memberUid, assigned ->
                    viewModel.adminSetDeviceMember(devId, memberUid, assigned)
                },
                onApplyGlobalThresholds = { settings ->
                    viewModel.adminApplyGlobalThresholds(settings)
                },
                onEmergencyAllPumpsOff = { viewModel.adminEmergencyAllPumpsOff() },
                onEmergencyForceManual = { viewModel.adminEmergencyForceManual() }
            )
        }
    }
}
