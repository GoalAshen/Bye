package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smart.plant.guardian.model.DeviceSettings
import kotlin.math.roundToInt

@Composable
fun ThresholdSlidersCard(
    currentSettings: DeviceSettings,
    isOperatorOrAdmin: Boolean,
    onSaveSettings: (DeviceSettings) -> Unit,
    onOpenScheduleDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    var dryPct by remember(currentSettings) { mutableIntStateOf(currentSettings.soilDryPercent) }
    var targetPct by remember(currentSettings) { mutableIntStateOf(currentSettings.soilTargetPercent) }
    var tempThreshold by remember(currentSettings) { mutableFloatStateOf(currentSettings.highTempAlertThresholdC) }
    var lowBattPct by remember(currentSettings) { mutableIntStateOf(currentSettings.lowBatteryAlertPercent) }
    var maxPumpRunMin by remember(currentSettings) { mutableIntStateOf(currentSettings.maxPumpRunTimeMinutes) }

    val hasChanges = dryPct != currentSettings.soilDryPercent ||
            targetPct != currentSettings.soilTargetPercent ||
            tempThreshold != currentSettings.highTempAlertThresholdC ||
            lowBattPct != currentSettings.lowBatteryAlertPercent ||
            maxPumpRunMin != currentSettings.maxPumpRunTimeMinutes

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("threshold_sliders_card"),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Thresholds & Automatic Rules",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                OutlinedButton(
                    onClick = onOpenScheduleDialog,
                    modifier = Modifier.testTag("open_schedule_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "Schedule",
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    Text("Schedule")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 1. Soil Dry Percent
            ThresholdSliderItem(
                label = "Soil Dry Threshold (Irrigation triggers below this)",
                valueText = "$dryPct%",
                value = dryPct.toFloat(),
                valueRange = 10f..60f,
                steps = 50,
                enabled = isOperatorOrAdmin,
                onValueChange = { dryPct = it.roundToInt() }
            )

            // 2. Soil Target Percent
            ThresholdSliderItem(
                label = "Soil Moisture Target (Pump stops once reached)",
                valueText = "$targetPct%",
                value = targetPct.toFloat(),
                valueRange = 40f..90f,
                steps = 50,
                enabled = isOperatorOrAdmin,
                onValueChange = { targetPct = it.roundToInt() }
            )

            // 3. High Temp Threshold
            ThresholdSliderItem(
                label = "High Temperature Alert Threshold",
                valueText = "${String.format("%.1f", tempThreshold)}°C",
                value = tempThreshold,
                valueRange = 25f..50f,
                steps = 25,
                enabled = isOperatorOrAdmin,
                onValueChange = { tempThreshold = it }
            )

            // 4. Low Battery Percent
            ThresholdSliderItem(
                label = "Low Battery Alert Threshold",
                valueText = "$lowBattPct%",
                value = lowBattPct.toFloat(),
                valueRange = 5f..40f,
                steps = 35,
                enabled = isOperatorOrAdmin,
                onValueChange = { lowBattPct = it.roundToInt() }
            )

            // 5. Max Pump Run Time
            ThresholdSliderItem(
                label = "Max Continuous Pump Run Time (Safety shutoff)",
                valueText = "$maxPumpRunMin min",
                value = maxPumpRunMin.toFloat(),
                valueRange = 1f..60f,
                steps = 59,
                enabled = isOperatorOrAdmin,
                onValueChange = { maxPumpRunMin = it.roundToInt() }
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (isOperatorOrAdmin) {
                Button(
                    onClick = {
                        val updated = currentSettings.copy(
                            soilDryPercent = dryPct,
                            soilTargetPercent = targetPct,
                            highTempAlertThresholdC = tempThreshold,
                            lowBatteryAlertPercent = lowBattPct,
                            maxPumpRunTimeMinutes = maxPumpRunMin
                        )
                        onSaveSettings(updated)
                    },
                    enabled = hasChanges,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_thresholds_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = "Save Settings",
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Text("Apply Device Thresholds")
                }
            } else {
                Text(
                    text = "Controls are read-only for Viewer role.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ThresholdSliderItem(
    label: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int,
    enabled: Boolean,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = valueText,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            enabled = enabled
        )
    }
}
