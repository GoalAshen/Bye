package com.smart.plant.guardian.model

enum class ThemeMode(val label: String) {
    WALLPAPER("Wallpaper colors"),
    FIXED_GREEN("Fixed green"),
    LIGHT("Light"),
    DARK("Dark"),
    SYSTEM("System")
}
