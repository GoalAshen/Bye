package com.smart.plant.guardian.model

data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val role: String = "viewer", // admin, operator, viewer, device
    val status: String = "pending", // pending, active, blocked
    val createdAt: Long = 0L,
    val lastLoginMs: Long = 0L
) {
    val isAdmin: Boolean get() = role.equals("admin", ignoreCase = true)
    val isOperator: Boolean get() = role.equals("operator", ignoreCase = true) || isAdmin
    val isViewer: Boolean get() = role.equals("viewer", ignoreCase = true)
    val isDeviceRole: Boolean get() = role.equals("device", ignoreCase = true)

    val isActive: Boolean get() = status.equals("active", ignoreCase = true)
    val isPending: Boolean get() = status.equals("pending", ignoreCase = true)
    val isBlocked: Boolean get() = status.equals("blocked", ignoreCase = true)

    companion object {
        const val ROLE_ADMIN = "admin"
        const val ROLE_OPERATOR = "operator"
        const val ROLE_VIEWER = "viewer"
        const val ROLE_DEVICE = "device"

        const val STATUS_PENDING = "pending"
        const val STATUS_ACTIVE = "active"
        const val STATUS_BLOCKED = "blocked"
    }
}
