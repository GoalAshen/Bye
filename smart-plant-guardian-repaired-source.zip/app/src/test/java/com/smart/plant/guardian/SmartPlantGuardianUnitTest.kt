package com.smart.plant.guardian

import com.smart.plant.guardian.model.Device
import com.smart.plant.guardian.model.DeviceMeta
import com.smart.plant.guardian.model.DeviceSensors
import com.smart.plant.guardian.model.DeviceSettings
import com.smart.plant.guardian.model.FirebaseConfig
import com.smart.plant.guardian.model.UserProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartPlantGuardianUnitTest {

    @Test
    fun testFirebaseConfigValidation() {
        val emptyConfig = FirebaseConfig()
        assertFalse("Empty config must not be configured", emptyConfig.isConfigured)
        assertFalse("Empty config must not be authenticated", emptyConfig.isAuthenticated)

        val validConfig = FirebaseConfig(
            databaseUrl = "https://my-plant-db.firebaseio.com/",
            apiKey = "AIzaSyFakeKey123",
            appId = "1:123456789:android:abcdef",
            idToken = "token_xyz",
            localId = "uid_123"
        )
        assertTrue("Complete config must be configured", validConfig.isConfigured)
        assertTrue("Config with tokens must be authenticated", validConfig.isAuthenticated)
        assertEquals("https://my-plant-db.firebaseio.com", validConfig.cleanDatabaseUrl)
    }

    @Test
    fun testUserProfileRolesAndStatuses() {
        val pendingViewer = UserProfile(
            uid = "user1",
            email = "user@test.com",
            role = UserProfile.ROLE_VIEWER,
            status = UserProfile.STATUS_PENDING
        )
        assertTrue(pendingViewer.isViewer)
        assertFalse(pendingViewer.isOperator)
        assertFalse(pendingViewer.isAdmin)
        assertTrue(pendingViewer.isPending)
        assertFalse(pendingViewer.isActive)

        val activeOperator = UserProfile(
            uid = "user2",
            email = "operator@test.com",
            role = UserProfile.ROLE_OPERATOR,
            status = UserProfile.STATUS_ACTIVE
        )
        assertTrue(activeOperator.isOperator)
        assertFalse(activeOperator.isAdmin)
        assertTrue(activeOperator.isActive)

        val activeAdmin = UserProfile(
            uid = "admin1",
            email = "admin@test.com",
            role = UserProfile.ROLE_ADMIN,
            status = UserProfile.STATUS_ACTIVE
        )
        assertTrue(activeAdmin.isAdmin)
        assertTrue(activeAdmin.isOperator) // Admin has operator privileges
        assertTrue(activeAdmin.isActive)

        val esp32Device = UserProfile(
            uid = "device1",
            email = "esp32@test.internal",
            role = UserProfile.ROLE_DEVICE,
            status = UserProfile.STATUS_ACTIVE
        )
        assertTrue(esp32Device.isDeviceRole)
    }

    @Test
    fun testDeviceOnlineWatchdogCalculation() {
        val serverTimeNow = 1700000000000L

        // Device reported 25 seconds ago -> ONLINE (within 60s)
        val onlineSensors = DeviceSensors(
            lastSeenEpochMs = serverTimeNow - 25_000L,
            batteryPercent = 85,
            lightPercent = 75
        )
        val onlineDevice = Device(id = "ESP32_01", sensors = onlineSensors)
        assertTrue("Device reported 25s ago must be online", onlineDevice.isOnline(serverTimeNow))
        assertEquals("Bright (75%)", onlineDevice.lightClassification)

        // Device reported 90 seconds ago -> OFFLINE (> 60s)
        val offlineSensors = DeviceSensors(
            lastSeenEpochMs = serverTimeNow - 90_000L,
            batteryPercent = 15,
            lightPercent = 10
        )
        val offlineDevice = Device(id = "ESP32_02", sensors = offlineSensors)
        assertFalse("Device reported 90s ago must be offline", offlineDevice.isOnline(serverTimeNow))
        assertEquals("Dark (10%)", offlineDevice.lightClassification)

        // Device missing lastSeenEpochMs -> OFFLINE
        val emptyDevice = Device(id = "ESP32_03", sensors = null)
        assertFalse("Device with no sensor data must be offline", emptyDevice.isOnline(serverTimeNow))
        assertEquals("--", emptyDevice.lightClassification)
    }

    @Test
    fun testDeviceDisplayNameFallback() {
        val devWithMeta = Device(
            id = "node_abc",
            meta = DeviceMeta(name = "Tomato Greenhouse")
        )
        assertEquals("Tomato Greenhouse", devWithMeta.displayName)

        val devWithoutMeta = Device(id = "node_xyz", meta = null)
        assertEquals("node_xyz", devWithoutMeta.displayName)
    }

    @Test
    fun testDefaultSettings() {
        val settings = DeviceSettings()
        assertEquals(30, settings.soilDryPercent)
        assertEquals(65, settings.soilTargetPercent)
        assertEquals(35.0f, settings.highTempAlertThresholdC)
        assertEquals(20, settings.lowBatteryAlertPercent)
        assertEquals(15, settings.maxPumpRunTimeMinutes)
        assertFalse(settings.schedule.enabled)
        assertEquals(7, settings.schedule.activeDays.size)
    }
}
