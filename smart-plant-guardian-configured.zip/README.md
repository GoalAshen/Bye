# Smart Plant Guardian 🌿💧

Native Android application built in Kotlin & Jetpack Compose (Material 3) to monitor and control an ESP32 plant-care and precision irrigation system over the internet using Firebase.

- **Package Name & Application ID:** `com.smart.plant.guardian`
- **Minimum SDK:** Android 5.0 (API 21) with core library desugaring
- **Target SDK:** Android 15 / 16 (API 36)
- **Zero Mock / Zero Fake Data:** Strictly live Firebase Realtime Database telemetry. Missing values show `--` and `"Waiting for device data…"`.

---

## 1. Firebase Setup Steps

1. Go to the [Firebase Console](https://console.firebase.google.com) and create or select a project.
2. Enable **Authentication**:
   - Go to **Build > Authentication > Sign-in method**.
   - Enable **Email/Password**.
3. Create a **Realtime Database**:
   - Go to **Build > Realtime Database**.
   - Click **Create Database** (choose your region).
   - Copy the database URL (e.g. `https://<your-project>-default-rtdb.firebaseio.com`).
4. Copy your **Web API Key** and **App ID**:
   - Go to **Project Settings > General**.
   - Under **Web API Key**, copy the key.
   - Under **Your apps**, add an Android app with package `com.smart.plant.guardian`. Copy the App ID (format: `1:123456789:android:abcdef`).
5. Open the Smart Plant Guardian app on Android:
   - On the initial **Sign-In Gate** screen, fill in:
     - **Database URL**
     - **Web API Key**
     - **Project ID**
     - **App ID**
     - **Email & Password**
   - Click **Register** (for first account) or **Sign In**. Credentials are saved securely to private SharedPreferences for automatic sign-in on future launches.

---

## 2. Setting the First Administrator

All newly registered accounts start in `viewer` role with `pending` status. To designate the first administrator:

1. Open the [Firebase Console > Realtime Database](https://console.firebase.google.com).
2. Expand the `/users` node.
3. Locate the user UID corresponding to your owner email address.
4. Update the fields:
   - `"role": "admin"`
   - `"status": "active"`
5. In the app on your phone, tap **"Check Status"**. The app immediately verifies the updated profile, activates your session, and presents the full dashboard with the admin shield icon.
6. Subsequent users and ESP32 device accounts can be approved, promoted, or blocked directly from within the app's **Admin Panel** without needing the Firebase Console.

---

## 3. How the ESP32 Auto-Registers and Gets Approved

1. **Auto-Discovery:** The app has NO manual "Add Device" or pairing buttons. The ESP32 discovers itself to the system by provisioning an account and writing its initial metadata:
   - ESP32 connects to WiFi.
   - ESP32 signs in or signs up with its dedicated email (e.g. `esp32-node1@plantguardian.internal`).
   - The ESP32 writes its metadata to:
     ```json
     /devices/{deviceId}/meta: {
       "name": "Garden Bed A",
       "locationName": "South Greenhouse",
       "latitude": 37.7749,
       "longitude": -122.4194,
       "firmwareVersion": "v1.4.2",
       "wifiSsid": "FarmNet_2.4G",
       "ipAddress": "192.168.1.142"
     }
     ```
2. **Approval by Admin:**
   - An administrator opens the app, taps the **Shield** icon in the top app bar to enter the **Admin Panel**.
   - In the **Users** tab, locate the ESP32 account and set its role to **`device`** and status to **`active`**.
   - In the **Devices** tab, the administrator can assign member users who are permitted to view and control that specific device (`/devices/{id}/members/{uid} = true` and `/users/{uid}/devices/{id} = true`).
3. **Secure Member-Level Discovery:**
   - Administrators and device accounts discover units by listening to `/devices.json`.
   - Member users discover only the devices assigned to them by querying `/users/{uid}/devices.json`, which points to their authorized devices under `/devices/{deviceId}.json`.

---

## 4. Complete Data Contract (`devices/{deviceId}/...`)

### ESP32 WRITES (App only reads these):
- `/devices/{deviceId}/meta`:
  - `name`: String
  - `locationName`: String
  - `latitude`: Double
  - `longitude`: Double
  - `firmwareVersion`: String
  - `wifiSsid`: String
  - `ipAddress`: String
- `/devices/{deviceId}/sensors`:
  - `temperatureC`: Float (°C)
  - `humidityPercent`: Float (%)
  - `soilZone1`: Int (0 - 100)
  - `soilZone2`: Int (0 - 100)
  - `soilZone3`: Int (0 - 100)
  - `lightPercent`: Int (0 - 100)
  - `isRaining`: Boolean
  - `batteryPercent`: Int (0 - 100 only)
  - `solarCharging`: Boolean (optional; hidden in UI if missing)
  - `lastSeenEpochMs`: Long (epoch milliseconds)
- `/devices/{deviceId}/status`:
  - `pumpOn`: Boolean (real relay state)
  - `mode`: String (`"AUTO"` or `"MANUAL"`)
  - `activeRunSeconds`: Int
- `/devices/{deviceId}/history/{pushId}`:
  - `timestampMs`: Long
  - `tempC`: Float
  - `humidity`: Float
  - `soilAvg`: Float
  - `zone1`: Int
  - `zone2`: Int
  - `zone3`: Int
  - `lightPercent`: Int
  - `batteryPercent`: Int

### APP WRITES (Operators and Admins only):
- `/devices/{deviceId}/commands`:
  - `pump`: Boolean
  - `mode`: String (`"AUTO"` or `"MANUAL"`)
  - `buzzer`: Boolean
  - `speaker`: Boolean
  - `ledRed`: Boolean
  - `ledBlue`: Boolean
  - `ledGreen`: Boolean
  - `ledYellow`: Boolean
- `/devices/{deviceId}/settings`:
  - `soilDryPercent`: Int (default 30)
  - `soilTargetPercent`: Int (default 65)
  - `highTempAlertThresholdC`: Float (default 35.0)
  - `lowBatteryAlertPercent`: Int (default 20)
  - `maxPumpRunTimeMinutes`: Int (default 15)
  - `schedule`:
    - `enabled`: Boolean
    - `startHour`: Int (0 - 23)
    - `startMinute`: Int (0 - 59)
    - `durationMinutes`: Int (1 - 60)
    - `activeDays`: List<Int> (`[1, 2, 3, 4, 5, 6, 7]`)
- `/devices/{deviceId}/members/{uid}`: Boolean (Admin only)
- `/audit/{pushId}`:
  - `uid`: String
  - `email`: String
  - `action`: String
  - `deviceId`: String
  - `timestampMs`: Long
  - `details`: String

---

## 5. Security Rules

Deploy the included `database.rules.json` to your Firebase Realtime Database. It enforces:
- Admins can list all users at `/users`; users can read their own profile at `/users/{uid}`.
- New user profiles can only be created as `viewer` + `pending`. Users cannot change their own role or status.
- Discovery on `/devices` is restricted to active admins and devices. Members discover authorized units via `/users/{uid}/devices`.
- Telemetry (`meta`, `sensors`, `status`, `history`) read requires active status and admin role, membership, or being the device itself.
- Telemetry write requires active status and the `device` role.
- Commands and settings write requires active status and admin or operator role.
- Audit log write requires active status; read is admin-only.

---

## 6. Build Instructions

Run a plain debug build with the Gradle wrapper:
```bash
./gradlew assembleDebug
```
The APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.
