package com.smart.plant.guardian.model

data class FirebaseConfig(
    val databaseUrl: String = "",
    val apiKey: String = "",
    val projectId: String = "",
    val appId: String = "",
    val email: String = "",
    val password: String = "",
    val idToken: String = "",
    val refreshToken: String = "",
    val localId: String = "",
    val tokenExpiresEpochMs: Long = 0L
) {
    val isConfigured: Boolean
        get() = databaseUrl.trim().isNotBlank() &&
                apiKey.trim().isNotBlank() &&
                appId.trim().isNotBlank()

    val isAuthenticated: Boolean
        get() = isConfigured && idToken.isNotBlank() && localId.isNotBlank()

    val cleanDatabaseUrl: String
        get() {
            var url = databaseUrl.trim()
            if (url.endsWith("/")) {
                url = url.substring(0, url.length - 1)
            }
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://$url"
            }
            return url
        }
}

/** Built-in Firebase project settings (from google-services.json). The app never asks for these. */
object FirebaseDefaults {
    const val DATABASE_URL = "https://smart-plant-guardian-default-rtdb.asia-south1.firebasedatabase.app"
    const val API_KEY = "AIzaSyDWdGtUvjhiaeed_YPdFOi2Ja_Gcq0Ih4o"
    const val PROJECT_ID = "smart-plant-guardian"
    const val APP_ID = "1:332853659277:android:91adfb469fb879652f44c4"
}
